# TASko BEAST v5.2 — strongest testable package

This package preserves the supplied `MASTER_FINAL_REFERENCE_LOCKED.md` and keeps implementation separate from the source-of-truth reference.

## Included
- Android WebView shell (`android/app`) with Arabic RTL UI and 20 control sections.
- Central JS core: eligibility, data integrity, A/A+, confirmation/edge, risk, drawdown, exposure/correlation/concentration, symbol-aware sizing, Smart Breathing, progressive protection ladder, order state machine, idempotency, paper execution, reconciliation, Kill Switch and Live Safety.
- Persistent browser-side state helper and retry helper.
- MT5 EA bridge with polling, account binding, validation, volume bounds, synchronous market execution and result reporting. Trading is `false` by default.
- Node relay for command/result/status exchange. Token auth is supported; production requires HTTPS and a durable authenticated deployment.
- Automated tests.

## Verification
`node --check web/src/core.js` PASS
`node --check server/relay.js` PASS
`node --test tests/core.test.js` PASS — 17/17

## Important
The package does **not** claim a real MT5 end-to-end execution test because MetaTrader 5/MetaEditor is not installed in this build environment. Before Live use, run the EA on MT5 Demo, verify WebRequest allow-listing, account binding, order check/execution, reconciliation, reconnect/recovery and protection behavior. Keep Live locked until those tests pass.

The reference defines the protection ladder but does not specify numeric thresholds. Therefore thresholds are explicit parameters and must be calibrated/tested; they are not falsely represented as canonical values from the reference.
