/* TASko BEAST — application controller.

   This is the piece that was completely missing before: it actually
   wires the tested safety core (core.js), the opportunity filter
   (opportunity.js), the new multi-timeframe scanner (market_scanner.js),
   the relay/MT5 bridge (bridge_client.js), the journal (journal.js) and
   the connection watchdog (watchdog.js) into one running engine that the
   UI (index.html) can start, stop, observe and emergency-kill.

   Design summary (see docs/ARCHITECTURE.md for the full picture):
   - Market data (ticks + H4/H1/M15 candles) always comes from the MT5
     terminal through the relay, in both DEMO and LIVE — there is no
     other real price source wired into this app, and this module never
     fabricates data. If the bridge is unreachable, the scan cycle is
     skipped and this is logged, never silently guessed at.
   - DEMO executes through the in-memory PaperBroker (core.js) against
     those same real MT5 ticks — a true "paper" simulation, not
     random/fake data.
   - LIVE sends real MARKET / MODIFY_POSITION / CLOSE_POSITION commands
     through the relay to the MT5 EA. LIVE requires LiveSafetyGate to
     pass *and* an explicit typed confirmation from the person before a
     single order can go out (see setMode()).
   - centralDecision() from core.js is the only place a trade is ever
     approved. This file never bypasses it. */

import {
  centralDecision, DEFAULT_CONFIG, PaperBroker, KillSwitch, LiveSafetyGate,
  managePosition, reconcile,
} from './core.js';
import { buildCommand } from './contracts.js';
import { scanMultiTimeframe } from './market_scanner.js';
import { normalizeCandidate } from './opportunity.js';
import { Journal } from './journal.js';
import { ConnectionWatchdog, buildDefensiveCommands } from './watchdog.js';
import { createDefaultStore } from './persistence.js';
import { BridgeClient } from './bridge_client.js';

const DEFAULT_SYMBOL = Object.freeze({
  name: 'XAUUSD', tickSize: 0.01, tickValue: 1, volumeMin: 0.01, volumeMax: 50, volumeStep: 0.01,
});

const DEFAULT_APP_CONFIG = Object.freeze({
  relayBaseUrl: '', relayToken: '', accountId: '',
  symbol: DEFAULT_SYMBOL,
  risk: DEFAULT_CONFIG,
  scanIntervalMs: 30000,
  manageIntervalMs: 10000,
  watchdogPollMs: 5000,
  watchdogDegradedMs: 10000,
  watchdogLostMs: 30000,
});

export class BeastApp {
  constructor({ onChange } = {}) {
    this.onChange = onChange || (() => {});
    this.store = createDefaultStore('tasko_beast_state_v1');
    this.journal = new Journal(this.store);
    this.config = { ...DEFAULT_APP_CONFIG, ...(this.store.load()?.config || {}) };

    this.mode = 'DEMO';
    this.killSwitch = new KillSwitch();
    this.liveSafetyGate = new LiveSafetyGate();
    this.paperBroker = new PaperBroker(100000, this.config.risk);

    this.bridge = null;
    this.liveAccount = null;
    this.livePositions = [];
    this.trackedLive = new Map(); // ticket -> {entry, initialStop, side, tickSize, tickValue}

    this.watchdog = new ConnectionWatchdog({
      degradedAfterMs: this.config.watchdogDegradedMs,
      lostAfterMs: this.config.watchdogLostMs,
      onStateChange: (next, prev) => this._onWatchdogChange(next, prev),
    });

    this.running = false;
    this.lastScan = null;
    this.lastCandidate = null;
    this._timers = [];
    this._connectMonitorSet = false;

    this._rebuildBridge();
  }

  /* ---------- configuration & connection ---------- */

  updateConfig(patch) {
    this.config = { ...this.config, ...patch };
    this.store.save({ ...(this.store.load() || {}), config: this.config });
    this._rebuildBridge();
    this.journal.system('CONFIG_UPDATED', { keys: Object.keys(patch) });
    this._emit();
  }

  _rebuildBridge() {
    if (!this.config.relayBaseUrl || !this.config.accountId) { this.bridge = null; return; }
    try {
      this.bridge = new BridgeClient({
        baseUrl: this.config.relayBaseUrl, token: this.config.relayToken, accountId: this.config.accountId,
      });
    } catch (e) {
      this.bridge = null;
      this.journal.connection('BRIDGE_INIT_FAILED', { error: String(e.message || e) });
    }
  }

  async testConnection() {
    if (!this.bridge) {
      this.journal.connection('CONNECTION_TEST_SKIPPED', { reason: 'RELAY_NOT_CONFIGURED' });
      return { ok: false, reason: 'RELAY_NOT_CONFIGURED' };
    }
    try {
      const health = await this.bridge.health();
      this.journal.connection('CONNECTION_TEST_OK', health);
      this._startWatchdogMonitor();
      this._emit();
      return { ok: true, health };
    } catch (e) {
      this.journal.connection('CONNECTION_TEST_FAILED', { error: String(e.message || e) });
      this._emit();
      return { ok: false, reason: String(e.message || e) };
    }
  }

  _startWatchdogMonitor() {
    if (this._connectMonitorSet) return;
    this._connectMonitorSet = true;
    const id = setInterval(() => this._pollWatchdog(), this.config.watchdogPollMs);
    this._timers.push(id);
  }

  async _pollWatchdog() {
    if (!this.bridge) { this.watchdog.evaluate(); this._emit(); return; }
    try {
      const status = await this.bridge.getStatus();
      if (status && Date.now() - (status.receivedAt || 0) < this.config.watchdogLostMs) {
        this.watchdog.heartbeat();
      } else {
        this.watchdog.evaluate();
      }
    } catch {
      this.watchdog.evaluate();
    }
    this._emit();
  }

  _onWatchdogChange(next, prev) {
    this.journal.connection(`WATCHDOG_${next}`, { previous: prev });
    if (next === 'LOST' && this.mode === 'LIVE') {
      const positions = [...this.trackedLive.values()].map((p, i) => ({ ...p, id: [...this.trackedLive.keys()][i], state: 'ENTERED' }));
      const commands = buildDefensiveCommands(positions, { accountId: this.config.accountId });
      commands.forEach((cmd) => this.bridge?.sendCommand(cmd).catch(() => {}));
      if (commands.length) {
        this.journal.risk('WATCHDOG_DEFENSIVE_CLOSE_QUEUED', { count: commands.length });
      }
    }
    this._emit();
  }

  /* ---------- mode switching (DEMO / LIVE) ---------- */

  setMode(mode, { liveChecks, typedConfirmation } = {}) {
    if (mode === 'DEMO') {
      this.mode = 'DEMO';
      this.journal.system('MODE_SET', { mode: 'DEMO' });
      this._emit();
      return { ok: true };
    }
    if (mode !== 'LIVE') return { ok: false, reason: 'INVALID_MODE' };

    // Two independent locks must both open before a single LIVE order can
    // ever be sent: (1) every LiveSafetyGate check, and (2) the person
    // must type the exact confirmation phrase — this is the "manual
    // second confirmation" requirement.
    const gateOk = this.liveSafetyGate.activate(liveChecks || {});
    const REQUIRED_PHRASE = 'CONFIRM LIVE';
    const phraseOk = typedConfirmation === REQUIRED_PHRASE;
    if (!gateOk || !phraseOk) {
      this.journal.risk('LIVE_ACTIVATION_DENIED', { gateOk, phraseOk });
      this._emit();
      return { ok: false, reason: !gateOk ? 'SAFETY_GATE_INCOMPLETE' : 'CONFIRMATION_PHRASE_MISMATCH', requiredPhrase: REQUIRED_PHRASE };
    }
    this.mode = 'LIVE';
    this.journal.system('MODE_SET', { mode: 'LIVE' });
    this._emit();
    return { ok: true };
  }

  lockLive() {
    this.liveSafetyGate.lock();
    if (this.mode === 'LIVE') this.mode = 'DEMO';
    this.journal.system('LIVE_LOCKED_MANUALLY');
    this._emit();
  }

  /* ---------- engine start/stop/kill ---------- */

  startEngine() {
    if (this.killSwitch.blocked()) {
      this.journal.risk('START_BLOCKED_KILL_SWITCH');
      this._emit();
      return { ok: false, reason: 'KILL_SWITCH_BLOCKED' };
    }
    if (this.running) return { ok: true };
    this.running = true;
    const scanId = setInterval(() => this.runScanCycle().catch((e) => this.journal.system('SCAN_CYCLE_ERROR', { error: String(e.message || e) })), this.config.scanIntervalMs);
    const manageId = setInterval(() => this.runManagementCycle().catch((e) => this.journal.system('MANAGE_CYCLE_ERROR', { error: String(e.message || e) })), this.config.manageIntervalMs);
    this._timers.push(scanId, manageId);
    this.journal.system('ENGINE_STARTED', { mode: this.mode });
    this._emit();
    return { ok: true };
  }

  stopEngine() {
    this.running = false;
    this._timers.forEach(clearInterval);
    this._timers = [];
    this._connectMonitorSet = false;
    this.journal.system('ENGINE_STOPPED');
    this._emit();
  }

  async emergencyKill() {
    this.killSwitch.emergencyStop();
    this.stopEngine();
    this.journal.risk('EMERGENCY_KILL_TRIGGERED', { mode: this.mode });
    if (this.mode === 'LIVE' && this.bridge) {
      const tickets = [...this.trackedLive.keys()];
      for (const ticket of tickets) {
        try {
          const cmd = buildCommand(this.config.accountId, 'CLOSE_POSITION', { ticket });
          await this.bridge.sendCommand(cmd);
          this.journal.trade('EMERGENCY_CLOSE_SENT', { ticket });
        } catch (e) {
          this.journal.system('EMERGENCY_CLOSE_FAILED', { ticket, error: String(e.message || e) });
        }
      }
    }
    this._emit();
  }

  /* ---------- data fetch helpers (bridge-backed, mode-independent) ---------- */

  async _fetchTick() {
    if (!this.bridge) return null;
    const cmd = buildCommand(this.config.accountId, 'GET_TICK', { symbol: this.config.symbol.name });
    const res = await this.bridge.sendAndWait(cmd, { timeoutMs: 8000 });
    return res?.ok ? res.tick : null;
  }

  async _fetchCandles() {
    if (!this.bridge) return null;
    const cmd = buildCommand(this.config.accountId, 'GET_CANDLES', {
      symbol: this.config.symbol.name, timeframes: ['H4', 'H1', 'M15'], count: 120,
    });
    const res = await this.bridge.sendAndWait(cmd, { timeoutMs: 12000 });
    return res?.ok ? res.candles : null;
  }

  async _fetchLiveAccountAndPositions() {
    if (!this.bridge) return;
    try {
      const accCmd = buildCommand(this.config.accountId, 'GET_ACCOUNT', {});
      const accRes = await this.bridge.sendAndWait(accCmd, { timeoutMs: 8000 });
      if (accRes?.ok) this.liveAccount = accRes.account;
      const posCmd = buildCommand(this.config.accountId, 'GET_POSITIONS', {});
      const posRes = await this.bridge.sendAndWait(posCmd, { timeoutMs: 8000 });
      if (posRes?.ok) this.livePositions = posRes.positions || [];
    } catch (e) {
      this.journal.connection('LIVE_ACCOUNT_FETCH_FAILED', { error: String(e.message || e) });
    }
  }

  /* ---------- scan cycle: Phase 2 + Phase 3 ---------- */

  async runScanCycle() {
    if (this.killSwitch.blocked()) return;
    if (!this.bridge) { this.journal.scan('SCAN_SKIPPED_NO_BRIDGE'); this._emit(); return; }

    const [tick, candles] = await Promise.all([this._fetchTick(), this._fetchCandles()]);
    this.lastScan = { ts: Date.now(), tick, hasCandles: !!candles };
    if (!tick || !candles) {
      this.journal.scan('SCAN_SKIPPED_NO_DATA', { hasTick: !!tick, hasCandles: !!candles });
      this._emit();
      return;
    }

    const scan = scanMultiTimeframe({
      h4: candles.H4, h1: candles.H1, m15: candles.M15, symbol: this.config.symbol,
    });
    this.lastScan.scanResult = scan;
    if (!scan.ok || !scan.candidate) {
      this.journal.scan('NO_QUALIFIED_SETUP', { reason: scan.reason });
      this._emit();
      return;
    }

    const candidate = normalizeCandidate(scan.candidate);
    if (!candidate) {
      this.journal.scan('CANDIDATE_REJECTED_BY_OPPORTUNITY_FILTER', { raw: scan.candidate });
      this._emit();
      return;
    }
    this.lastCandidate = candidate;

    if (this.mode === 'LIVE') await this._fetchLiveAccountAndPositions();
    const account = this.mode === 'LIVE' ? this.liveAccount : this.paperBroker.snapshot();
    if (!account) {
      this.journal.scan('NO_ACCOUNT_SNAPSHOT_AVAILABLE');
      this._emit();
      return;
    }

    const decision = centralDecision({
      account, market: tick, candidate, symbol: this.config.symbol, config: this.config.risk, portfolio: this._portfolioRisk(),
    });
    this.journal.scan('CENTRAL_DECISION', { approved: decision.approved, reason: decision.reason });
    if (!decision.approved) { this._emit(); return; }

    await this._executeApproved(decision, candidate, tick);
    this._emit();
  }

  _portfolioRisk() {
    const positions = this.mode === 'LIVE' ? this.livePositions : this.paperBroker.positions();
    const open = positions.filter((p) => p.state !== 'EXITED').length;
    // Conservative placeholder until true cross-symbol correlation tracking
    // is added: exposure grows with each open position, capped by the
    // same maxExposurePct gate in core.js. Honest limitation, logged.
    return { exposurePct: open * (this.config.risk.riskPerTradePct || 0.5), correlationRiskPct: 0, concentrationPct: 0 };
  }

  async _executeApproved(decision, candidate, tick) {
    if (this.mode === 'DEMO') {
      const order = {
        clientOrderId: `demo-${Date.now()}`, symbol: this.config.symbol.name, side: candidate.side,
        lot: decision.lot, price: candidate.side === 'BUY' ? tick.ask : tick.bid,
        stop: candidate.stop, target: candidate.target,
        tickSize: this.config.symbol.tickSize, tickValue: this.config.symbol.tickValue,
      };
      const result = this.paperBroker.submit(order);
      this.journal.trade('DEMO_ORDER_SUBMITTED', { result, decision });
      return;
    }
    // LIVE
    const cmd = buildCommand(this.config.accountId, 'MARKET', {
      symbol: this.config.symbol.name, side: candidate.side, volume: decision.lot,
      sl: candidate.stop, tp: candidate.target,
    });
    try {
      const res = await this.bridge.sendAndWait(cmd, { timeoutMs: 15000 });
      this.journal.trade('LIVE_ORDER_RESULT', { ok: res?.ok, reason: res?.reason, decision });
      if (res?.ok && res.ticket) {
        this.trackedLive.set(String(res.ticket), {
          side: candidate.side, entry: candidate.entry, initialStop: candidate.stop, stop: candidate.stop,
          protectionStage: 0, tickSize: this.config.symbol.tickSize, tickValue: this.config.symbol.tickValue,
        });
      }
    } catch (e) {
      this.journal.trade('LIVE_ORDER_SEND_FAILED', { error: String(e.message || e) });
    }
  }

  /* ---------- management cycle: Phase 4 ---------- */

  async runManagementCycle() {
    if (this.killSwitch.blocked()) return;
    const tick = await this._fetchTick();
    if (!tick) { this._emit(); return; }

    if (this.mode === 'DEMO') {
      this.paperBroker.mark({ ...tick, symbol: this.config.symbol.name });
      this._emit();
      return;
    }

    // LIVE: reconcile our local view against the broker's truth, then
    // advance the monotonic protection ladder per tracked ticket and
    // push any stop tightening back to the EA.
    await this._fetchLiveAccountAndPositions();
    const local = { account: { id: this.config.accountId }, positions: [...this.trackedLive.entries()].map(([id, p]) => ({ id, state: 'ENTERED', ...p })) };
    const remote = { account: { id: this.config.accountId }, positions: this.livePositions.map((p) => ({ id: String(p.ticket), state: p.state || 'ENTERED', symbol: p.symbol, side: p.side, lot: p.lot, stop: p.stop, target: p.target })) };
    const check = reconcile(local, remote);
    if (!check.ok) this.journal.risk('RECONCILE_MISMATCH', { issues: check.issues });

    for (const [ticket, pos] of this.trackedLive.entries()) {
      const stillOpen = this.livePositions.some((p) => String(p.ticket) === ticket && p.state !== 'EXITED' && p.state !== 'CLOSED');
      if (!stillOpen) { this.trackedLive.delete(ticket); this.journal.trade('POSITION_CLOSED_BY_BROKER', { ticket }); continue; }
      const updated = managePosition({ position: { ...pos, side: pos.side }, market: tick, config: this.config.risk });
      if (updated.stop !== pos.stop) {
        try {
          const cmd = buildCommand(this.config.accountId, 'MODIFY_POSITION', { ticket, sl: updated.stop });
          await this.bridge.sendCommand(cmd);
          this.journal.trade('PROTECTIVE_STOP_UPDATED', { ticket, stop: updated.stop, stage: updated.protectionStage });
        } catch (e) {
          this.journal.system('PROTECTIVE_STOP_SEND_FAILED', { ticket, error: String(e.message || e) });
        }
      }
      this.trackedLive.set(ticket, { ...pos, stop: updated.stop, protectionStage: updated.protectionStage });
    }
    this._emit();
  }

  /* ---------- state snapshot for the UI ---------- */

  getState() {
    return {
      mode: this.mode,
      running: this.running,
      killSwitch: { stopped: this.killSwitch.stopped, emergency: this.killSwitch.emergency },
      liveUnlocked: this.liveSafetyGate.unlocked,
      watchdog: this.watchdog.state,
      bridgeConfigured: !!this.bridge,
      account: this.mode === 'LIVE' ? this.liveAccount : this.paperBroker.snapshot(),
      positions: this.mode === 'LIVE' ? this.livePositions : this.paperBroker.positions(),
      lastScan: this.lastScan,
      lastCandidate: this.lastCandidate,
      journal: this.journal.recent(50),
      journalStats: this.journal.stats(),
      config: this.config,
    };
  }

  _emit() { this.onChange(this.getState()); }
}
