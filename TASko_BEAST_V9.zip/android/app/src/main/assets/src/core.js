/* TASko BEAST v5.3 — deterministic safety core. No broker secrets. */
export const VERSION='5.4.0';
export const ENGINE_MODE='DEMO_FIRST';
export const STATES=['SCANNING','ANALYZING','WAITING','NO_TRADE','TRADE_APPROVED','ENTERED','PROTECTED','MANAGING','EXITED','ERROR','RECOVERY'];
export const GRADES=['INELIGIBLE','C','B','A','A+'];
export const LADDER=['PART_1','PART_2','FULL_PROFIT','ABOVE_FULL','BE'];
const finite=Number.isFinite;
const round=(n,d=8)=>Number(n.toFixed(d));
const floorStep=(n,s)=>s>0?Math.floor((n+1e-12)/s)*s:0;
export const DEFAULT_CONFIG=Object.freeze({
 schemaVersion:1,riskPerTradePct:.5,maxDrawdownPct:3,maxExposurePct:10,maxCorrelationRiskPct:10,maxConcentrationPct:25,
 maxDataAgeMs:5000,minEdge:0,maxSpread:null,maxSlippage:null,estimatedCommission:0,estimatedSlippageCost:0,maxMarginUsagePct:70,minFreeMarginPct:30,liveUnlocked:false,
 breathing:Object.freeze({volatilityMultiplier:1.5,structureBufferTicks:1,minimumStopMoveTicks:1}),
 protection:Object.freeze({part1R:1,part1LockR:.1,part2R:1.5,part2LockR:.5,fullR:2,fullLockR:1,aboveFullR:3,aboveFullLockR:2,beR:4,beLockR:0})
});
export function validateMarket(m,maxAge=5000,now=Date.now()){
 const ok=!!m&&finite(m.bid)&&finite(m.ask)&&m.bid>0&&m.ask>=m.bid&&finite(m.timestamp)&&now-m.timestamp>=0&&now-m.timestamp<=maxAge&&m.integrity===true;
 return{ok,reason:ok?'OK':'UNKNOWN_OR_STALE_MARKET_DATA'};
}
export function validateSymbol(s){
 const ok=!!s&&finite(s.tickSize)&&s.tickSize>0&&finite(s.tickValue)&&s.tickValue>0&&finite(s.volumeMin)&&s.volumeMin>0&&finite(s.volumeMax)&&s.volumeMax>=s.volumeMin&&finite(s.volumeStep)&&s.volumeStep>0;
 return{ok,reason:ok?'OK':'INVALID_SYMBOL_SPEC'};
}
export function sizeByRisk({equity,riskPct,entry,stop,symbol,estimatedCosts=0}){
 const v=validateSymbol(symbol);if(!v.ok)return{ok:false,lot:0,reason:v.reason};
 if(!(finite(equity)&&equity>0&&finite(riskPct)&&riskPct>0&&riskPct<=100&&finite(entry)&&finite(stop)&&entry!==stop))return{ok:false,lot:0,reason:'INVALID_RISK_INPUT'};
 const riskMoney=equity*riskPct/100;
 const lossPerLot=Math.abs(entry-stop)/symbol.tickSize*symbol.tickValue+Math.max(0,estimatedCosts);
 if(!(finite(lossPerLot)&&lossPerLot>0))return{ok:false,lot:0,riskMoney,reason:'INVALID_MONETARY_RISK'};
 const raw=riskMoney/lossPerLot,lot=floorStep(Math.min(raw,symbol.volumeMax),symbol.volumeStep);
 if(lot<symbol.volumeMin)return{ok:false,lot:0,riskMoney,lossPerLot,reason:'RISK_TOO_SMALL_FOR_MIN_VOLUME'};
 return{ok:true,lot:round(lot),riskMoney,lossPerLot,reason:'OK'};
}
export function centralDecision({account,market,candidate,symbol,config=DEFAULT_CONFIG,portfolio={}}){
 const no=reason=>({approved:false,state:'NO_TRADE',reason,ts:Date.now()});
 if(!account||account.connectionStatus!=='VERIFIED'||!['DEMO','LIVE'].includes(account.type))return no('UNKNOWN_ACCOUNT_OR_CONNECTION');
 if(!(finite(account.equity)&&account.equity>0))return no('UNKNOWN_ACCOUNT_EQUITY');
 if(account.canTrade!==true)return no('TRADING_NOT_ALLOWED');
 if(account.type==='LIVE'&&!config.liveUnlocked)return no('LIVE_LOCKED');
 if(!finite(account.drawdownPct)||account.drawdownPct<0||account.drawdownPct>=config.maxDrawdownPct)return no('DRAWDOWN_LIMIT');
 const md=validateMarket(market,config.maxDataAgeMs);if(!md.ok)return no(md.reason);
 if(!candidate||!['A','A+'].includes(candidate.grade))return no('ONLY_A_OR_A_PLUS');
 if(candidate.confirmation!==true||!finite(candidate.edge)||candidate.edge<=config.minEdge)return no('EDGE_OR_CONFIRMATION_FAIL');
 if(!finite(candidate.entry)||!finite(candidate.stop)||!finite(candidate.target)||candidate.entry===candidate.stop)return no('INVALID_TRADE_LEVELS');
 if(!finite(portfolio.exposurePct??0)||!finite(portfolio.correlationRiskPct??0)||!finite(portfolio.concentrationPct??0))return no('UNKNOWN_PORTFOLIO_RISK');
 if((portfolio.exposurePct??0)>=config.maxExposurePct)return no('EXPOSURE_LIMIT');
 if((portfolio.correlationRiskPct??0)>=config.maxCorrelationRiskPct)return no('CORRELATION_LIMIT');
 if((portfolio.concentrationPct??0)>=config.maxConcentrationPct)return no('CONCENTRATION_LIMIT');
 if(finite(portfolio.marginUsagePct)&&portfolio.marginUsagePct>=config.maxMarginUsagePct)return no('MARGIN_USAGE_LIMIT');
 if(finite(portfolio.freeMarginPct)&&portfolio.freeMarginPct<config.minFreeMarginPct)return no('FREE_MARGIN_LIMIT');
 if(finite(config.maxSpread)&&(!finite(market.spread)||market.spread>config.maxSpread))return no('SPREAD_LIMIT');
 if(finite(config.maxSlippage)&&(!finite(market.slippage)||market.slippage>config.maxSlippage))return no('SLIPPAGE_LIMIT');
 const s=sizeByRisk({equity:account.equity,riskPct:config.riskPerTradePct,entry:candidate.entry,stop:candidate.stop,symbol,estimatedCosts:(candidate.estimatedCosts||0)+config.estimatedCommission+config.estimatedSlippageCost});
 if(!s.ok)return no(s.reason);
 return{approved:true,state:'TRADE_APPROVED',reason:'ALL_CENTRAL_GATES_PASSED',lot:s.lot,riskMoney:s.riskMoney,candidate,ts:Date.now()};
}
export class KillSwitch{constructor(){this.stopped=false;this.emergency=false}stop(){this.stopped=true}emergencyStop(){this.stopped=true;this.emergency=true}reset(){if(this.emergency)return false;this.stopped=false;return true}recover(){return this.emergency?false:this.reset()}clearEmergencyAfterRecovery(){this.emergency=false;this.stopped=true}blocked(){return this.stopped||this.emergency}}
export class IdempotencyGuard{constructor(){this.ids=new Set}accept(id){if(!id||this.ids.has(id))return false;this.ids.add(id);return true}}
export function breathingStop({position,market,config=DEFAULT_CONFIG}){
 const tick=position.tickSize||market.tickSize;if(!(tick>0))return{ok:false,stop:position.stop,reason:'NO_TICK_SIZE'};
 const vol=Math.max(0,market.volatilityTicks||0),buffer=Math.max(config.breathing.structureBufferTicks,vol*config.breathing.volatilityMultiplier);
 const desired=position.side==='BUY'?market.bid-buffer*tick:market.ask+buffer*tick;
 const monotonic=position.side==='BUY'?Math.max(position.stop,desired):Math.min(position.stop,desired);
 const changed=Math.abs(monotonic-position.stop)>=config.breathing.minimumStopMoveTicks*tick;
 return{ok:true,stop:round(changed?monotonic:position.stop),bufferTicks:buffer,changed,reason:'SMART_BREATHING'};
}
export function protectionDecision({position,market,config=DEFAULT_CONFIG}){
 const risk=Math.abs(position.entry-position.initialStop);if(!(risk>0))return{stage:position.protectionStage??0,stop:position.stop,changed:false,reason:'NO_INITIAL_RISK'};
 const move=position.side==='BUY'?market.bid-position.entry:position.entry-market.ask,r=move/risk,p=config.protection;let stage=position.protectionStage??0,lockR=0;
 if(r>=p.beR){stage=4;lockR=p.beLockR}else if(r>=p.aboveFullR){stage=3;lockR=p.aboveFullLockR}else if(r>=p.fullR){stage=2;lockR=p.fullLockR}else if(r>=p.part2R){stage=1;lockR=p.part2LockR}else if(r>=p.part1R){stage=Math.max(stage,0);lockR=p.part1LockR}else return{stage,stop:position.stop,changed:false,reason:'WAITING_FOR_PROTECTION_STAGE'};
 const target=position.side==='BUY'?position.entry+lockR*risk:position.entry-lockR*risk,stop=position.side==='BUY'?Math.max(position.stop,target):Math.min(position.stop,target);
 return{stage,stop:round(stop),changed:stop!==position.stop||stage>(position.protectionStage??0),reason:LADDER[stage],r};
}
export function managePosition({position,market,config=DEFAULT_CONFIG}){const b=breathingStop({position,market,config}),p=protectionDecision({position,market,config});let stop=position.stop,stage=position.protectionStage??0;if(b.ok&&b.changed)stop=position.side==='BUY'?Math.max(stop,b.stop):Math.min(stop,b.stop);if(p.changed){stage=Math.max(stage,p.stage);stop=position.side==='BUY'?Math.max(stop,p.stop):Math.min(stop,p.stop)}return{...position,stop,protectionStage:stage,state:stage>0?'PROTECTED':'MANAGING',breathing:b,protection:p}}
export class OrderStateMachine{constructor(){this.state='NEW'}transition(next){const allowed={NEW:['VALIDATED','REJECTED'],VALIDATED:['SUBMITTED','REJECTED'],SUBMITTED:['PARTIAL','FILLED','REJECTED'],PARTIAL:['PARTIAL','FILLED','CANCELLED','REJECTED'],FILLED:['PROTECTED','MANAGING','EXIT_REQUESTED'],PROTECTED:['PROTECTED','MANAGING','EXIT_REQUESTED'],MANAGING:['PROTECTED','EXIT_REQUESTED'],EXIT_REQUESTED:['EXITED','ERROR'],EXITED:[],REJECTED:[],CANCELLED:[],ERROR:['RECOVERY'],RECOVERY:['VALIDATED','REJECTED']};if(!allowed[this.state]?.includes(next))throw new Error(`INVALID_ORDER_TRANSITION:${this.state}->${next}`);this.state=next;return this.state}}
export class PaperBroker{
 constructor(balance=100000,config=DEFAULT_CONFIG){this.config=config;this.account={id:'PAPER-001',type:'DEMO',connectionStatus:'VERIFIED',balance,equity:balance,currency:'USD',canTrade:true,drawdownPct:0};this.peak=balance;this._positions=new Map;this.orders=new Map;this.guard=new IdempotencyGuard()}
 snapshot(){return structuredClone(this.account)}
 submit(o){if(!this.account.canTrade)return{state:'REJECTED',reason:'ACCOUNT_NOT_TRADEABLE'};if(!this.guard.accept(o.clientOrderId))return this.orders.get(o.clientOrderId);if(!(o.lot>0&&o.price>0&&o.stop>0&&o.target>0&&o.symbol))return{state:'REJECTED',reason:'INVALID_ORDER'};const id=`P-${o.clientOrderId}`,r={clientOrderId:o.clientOrderId,brokerOrderId:id,state:'FILLED',fillPrice:o.price};this.orders.set(o.clientOrderId,r);this._positions.set(id,{id,symbol:o.symbol,side:o.side,lot:o.lot,entry:o.price,currentPrice:o.price,stop:o.stop,initialStop:o.stop,target:o.target,tickSize:o.tickSize||.01,tickValue:o.tickValue||1,protectionStage:0,state:'ENTERED',realizedPnl:0});return r}
 mark(t){for(const p of this._positions.values()){if(p.symbol!==t.symbol||p.state==='EXITED')continue;const price=p.side==='BUY'?t.bid:t.ask;p.currentPrice=price;p.realizedPnl=(p.side==='BUY'?price-p.entry:p.entry-price)/p.tickSize*p.tickValue*p.lot;Object.assign(p,managePosition({position:p,market:t,config:this.config}));const stop=p.side==='BUY'?price<=p.stop:price>=p.stop,tp=p.side==='BUY'?price>=p.target:price<=p.target;if(stop||tp){p.state='EXITED';this.account.balance+=p.realizedPnl}}const floating=[...this._positions.values()].filter(p=>p.state!=='EXITED').reduce((s,p)=>s+p.realizedPnl,0);this.account.equity=this.account.balance+floating;this.peak=Math.max(this.peak,this.account.equity);this.account.drawdownPct=this.peak>0?Math.max(0,(this.peak-this.account.equity)/this.peak*100):0}
 positions(){return structuredClone([...this._positions.values()])}
}
export function portfolioRiskAfterTrade({portfolio={},tradeRiskPct=0}={}){
 const exposure=Number(portfolio.exposurePct??0)+Math.max(0,tradeRiskPct);
 return {exposurePct:exposure,correlationRiskPct:Number(portfolio.correlationRiskPct??0),concentrationPct:Number(portfolio.concentrationPct??0),withinLimit:exposure<DEFAULT_CONFIG.maxExposurePct};
}
export function reconcile(local,remote){const issues=[];if(local.account?.id!==remote.account?.id)issues.push('ACCOUNT_MISMATCH');const a=new Map((local.positions||[]).filter(x=>x.state!=='EXITED').map(x=>[String(x.id),x])),b=new Map((remote.positions||[]).filter(x=>x.state!=='EXITED').map(x=>[String(x.id),x]));for(const id of a.keys())if(!b.has(id))issues.push('LOCAL_MISSING_REMOTE:'+id);for(const id of b.keys())if(!a.has(id))issues.push('REMOTE_MISSING_LOCAL:'+id);for(const[id,p]of a){const q=b.get(id);if(!q)continue;for(const k of ['symbol','side','lot','stop','target'])if(p[k]!==undefined&&q[k]!==undefined&&p[k]!==q[k])issues.push(`POSITION_MISMATCH:${id}:${k}`)}return{ok:issues.length===0,issues}}
export class LiveSafetyGate{constructor(){this.unlocked=false}activate(c){const r=['demoGate','connectionTest','accountVerified','symbolVerified','executionVerified','riskVerified'];this.unlocked=r.every(k=>c?.[k]===true);return this.unlocked}lock(){this.unlocked=false}}
export const VERSION_CONTROL=Object.freeze({MASTER_ORIGINAL:'LOCKED',DEVELOPMENT:'ACTIVE',TEST_BUILD:'TEST',LAST_KNOWN_GOOD:'STABLE'});
