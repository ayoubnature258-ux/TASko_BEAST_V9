/* TASko BEAST — multi-timeframe market scanner.

   This module implements the previously-missing "Market Scanner & Regime"
   and "Structure & Liquidity" stages of the pipeline: H4 -> H1 -> M15.

   IMPORTANT — what this is and is not:
   This is a deterministic, rule-based technical-structure scanner
   (swing highs/lows, break-of-structure, liquidity-sweep detection,
   ATR-based regime classification). It is NOT a proven profitable
   strategy and makes no such claim. It only ever *proposes* a candidate
   trade; core.js's centralDecision() remains the single authority that
   approves or rejects every trade against the risk gates. Nothing in
   this file bypasses centralDecision, and nothing here executes an
   order by itself. */

const finite = Number.isFinite;

function validCandles(candles) {
  return Array.isArray(candles) && candles.every((c) => c
    && finite(c.open) && finite(c.high) && finite(c.low) && finite(c.close) && finite(c.time));
}

/* Fractal swing detection: a HIGH/LOW confirmed by `lookback` candles on
   both sides — the standard, well-known definition of a swing point. */
export function findSwings(candles, lookback = 2) {
  const out = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    const c = candles[i];
    let isHigh = true;
    let isLow = true;
    for (let k = 1; k <= lookback; k++) {
      if (candles[i - k].high >= c.high || candles[i + k].high >= c.high) isHigh = false;
      if (candles[i - k].low <= c.low || candles[i + k].low <= c.low) isLow = false;
    }
    if (isHigh) out.push({ index: i, type: 'HIGH', price: c.high, time: c.time });
    if (isLow) out.push({ index: i, type: 'LOW', price: c.low, time: c.time });
  }
  return out;
}

/* Classic structure read: higher-high + higher-low => BULLISH,
   lower-high + lower-low => BEARISH, anything else => RANGE/UNKNOWN. */
export function structureBias(swings) {
  const highs = swings.filter((s) => s.type === 'HIGH').slice(-3);
  const lows = swings.filter((s) => s.type === 'LOW').slice(-3);
  if (highs.length < 2 || lows.length < 2) return { bias: 'UNKNOWN', reason: 'INSUFFICIENT_SWINGS' };
  const hh = highs.at(-1).price > highs.at(-2).price;
  const hl = lows.at(-1).price > lows.at(-2).price;
  const lh = highs.at(-1).price < highs.at(-2).price;
  const ll = lows.at(-1).price < lows.at(-2).price;
  if (hh && hl) return { bias: 'BULLISH', reason: 'HIGHER_HIGH_HIGHER_LOW', highs, lows };
  if (lh && ll) return { bias: 'BEARISH', reason: 'LOWER_HIGH_LOWER_LOW', highs, lows };
  return { bias: 'RANGE', reason: 'MIXED_STRUCTURE', highs, lows };
}

export function atr(candles, period = 14) {
  if (candles.length < period + 1) return null;
  let sum = 0;
  for (let i = candles.length - period; i < candles.length; i++) {
    const c = candles[i];
    const p = candles[i - 1];
    sum += Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
  }
  return sum / period;
}

/* Regime classification used for the "Market Scanner & Regime" screen:
   TREND / RANGE / VOLATILE / UNKNOWN. Thresholds are deliberately simple
   and documented so they can be tuned per instrument, not hidden magic. */
export function classifyRegime(candles, { atrPeriod = 14, volatilityThreshold = 0.01, trendRangeMultiple = 6 } = {}) {
  const a = atr(candles, atrPeriod);
  if (a == null) return { regime: 'UNKNOWN', reason: 'INSUFFICIENT_DATA' };
  const recent = candles.slice(-20);
  const range = Math.max(...recent.map((c) => c.high)) - Math.min(...recent.map((c) => c.low));
  const avgClose = recent.reduce((s, c) => s + c.close, 0) / recent.length;
  const volatilityRatio = avgClose > 0 ? a / avgClose : 0;
  if (volatilityRatio > volatilityThreshold) return { regime: 'VOLATILE', atr: a, volatilityRatio };
  if (range > a * trendRangeMultiple) return { regime: 'TREND', atr: a, volatilityRatio };
  return { regime: 'RANGE', atr: a, volatilityRatio };
}

/* A recent, still-untouched swing high/low is treated as a resting
   liquidity pool (stop-loss cluster). */
export function liquidityZones(swings, count = 3) {
  const highs = swings.filter((s) => s.type === 'HIGH').slice(-count).map((s) => ({ ...s, side: 'SELL_SIDE_LIQUIDITY' }));
  const lows = swings.filter((s) => s.type === 'LOW').slice(-count).map((s) => ({ ...s, side: 'BUY_SIDE_LIQUIDITY' }));
  return [...highs, ...lows];
}

/* A liquidity sweep: the latest candle wicks through a resting pool and
   closes back on the "right" side of it — the classic stop-hunt/reversal
   signature. */
export function detectSweep(candles, zones, direction) {
  const last = candles.at(-1);
  if (!last) return null;
  if (direction === 'BULLISH') {
    for (const z of zones.filter((x) => x.side === 'BUY_SIDE_LIQUIDITY')) {
      if (last.low < z.price && last.close > z.price) return { swept: z, candle: last };
    }
  } else if (direction === 'BEARISH') {
    for (const z of zones.filter((x) => x.side === 'SELL_SIDE_LIQUIDITY')) {
      if (last.high > z.price && last.close < z.price) return { swept: z, candle: last };
    }
  }
  return null;
}

/* Break of structure: latest candle closes beyond the most recent
   opposing swing in the trade direction. */
export function detectBOS(candles, swings, direction) {
  const last = candles.at(-1);
  if (!last) return null;
  if (direction === 'BULLISH') {
    const ref = swings.filter((s) => s.type === 'HIGH').at(-1);
    if (ref && last.close > ref.price) return { broke: ref, candle: last };
  } else if (direction === 'BEARISH') {
    const ref = swings.filter((s) => s.type === 'LOW').at(-1);
    if (ref && last.close < ref.price) return { broke: ref, candle: last };
  }
  return null;
}

export function analyzeTimeframe(candles, { lookback = 2 } = {}) {
  if (!validCandles(candles) || candles.length < lookback * 2 + 5) {
    return { ok: false, reason: 'INSUFFICIENT_OR_INVALID_DATA' };
  }
  const swings = findSwings(candles, lookback);
  return {
    ok: true,
    swings,
    structure: structureBias(swings),
    zones: liquidityZones(swings),
    regime: classifyRegime(candles),
  };
}

/* Full H4 -> H1 -> M15 scan.
   Input:  { h4, h1, m15 (candle arrays, oldest -> newest), symbol, config }
   Output: { ok, reason?, candidate|null, h4, h1, m15 }
   `candidate` (when present) is already shaped for opportunity.js's
   normalizeCandidate()/scanOpportunities() and for core.js's
   centralDecision() — this function never approves a trade itself. */
export function scanMultiTimeframe({ h4, h1, m15, symbol, config = {} } = {}) {
  const cfg = { lookback: 2, minStopTicks: 5, targetR: 2, ...config };
  const h4a = analyzeTimeframe(h4, cfg);
  const h1a = analyzeTimeframe(h1, cfg);
  const m15a = analyzeTimeframe(m15, cfg);
  if (!h4a.ok || !h1a.ok || !m15a.ok) {
    return { ok: false, reason: 'INSUFFICIENT_DATA', h4: h4a, h1: h1a, m15: m15a };
  }

  const htfBias = h4a.structure.bias;
  if (htfBias !== 'BULLISH' && htfBias !== 'BEARISH') {
    return { ok: true, candidate: null, reason: 'NO_H4_BIAS', h4: h4a, h1: h1a, m15: m15a };
  }
  if (h1a.structure.bias !== htfBias) {
    return { ok: true, candidate: null, reason: 'H1_MISALIGNED_WITH_H4', h4: h4a, h1: h1a, m15: m15a };
  }

  const bos = detectBOS(m15, m15a.swings, htfBias);
  if (!bos) {
    return { ok: true, candidate: null, reason: 'NO_M15_BREAK_OF_STRUCTURE', h4: h4a, h1: h1a, m15: m15a };
  }
  const sweep = detectSweep(m15, m15a.zones, htfBias);

  const tick = symbol?.tickSize || 0.0001;
  const lastClose = m15.at(-1).close;
  const lookAt = m15.slice(-cfg.lookback * 4);
  const structuralStop = htfBias === 'BULLISH'
    ? Math.min(...lookAt.map((c) => c.low))
    : Math.max(...lookAt.map((c) => c.high));
  const stopDistance = Math.max(Math.abs(lastClose - structuralStop), cfg.minStopTicks * tick);
  const entry = lastClose;
  const stop = htfBias === 'BULLISH' ? entry - stopDistance : entry + stopDistance;
  const target = htfBias === 'BULLISH' ? entry + stopDistance * cfg.targetR : entry - stopDistance * cfg.targetR;

  const candidate = {
    symbol: symbol?.name || null,
    side: htfBias === 'BULLISH' ? 'BUY' : 'SELL',
    grade: sweep ? 'A+' : 'A',
    confirmation: true,
    confidence: sweep ? 0.85 : 0.72,
    entry: Number(entry.toFixed(8)),
    stop: Number(stop.toFixed(8)),
    target: Number(target.toFixed(8)),
    edge: cfg.targetR,
    reasoning: {
      htfBias,
      h1Aligned: true,
      m15Bos: bos,
      m15Sweep: sweep,
      regime: { h4: h4a.regime.regime, h1: h1a.regime.regime, m15: m15a.regime.regime },
    },
  };
  return { ok: true, candidate, reason: 'CANDIDATE_FOUND', h4: h4a, h1: h1a, m15: m15a };
}
