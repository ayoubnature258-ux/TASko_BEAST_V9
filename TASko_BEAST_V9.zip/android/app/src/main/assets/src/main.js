import { BeastApp } from './app.js';

const SCREENS = [
  ['dashboard', 'Dashboard'], ['scanner', 'Scanner'], ['positions', 'Positions'],
  ['journal', 'Journal'], ['stats', 'Stats'], ['settings', 'Settings'],
  ['diagnostics', 'Diagnostics'], ['versions', 'Versions'],
];
const nav = document.getElementById('nav');
SCREENS.forEach(([id, label], i) => {
  const b = document.createElement('button');
  b.className = 'btn' + (i === 0 ? ' active' : '');
  b.textContent = label;
  b.dataset.screen = id;
  b.onclick = () => showScreen(id);
  nav.appendChild(b);
});
function showScreen(id) {
  document.querySelectorAll('.screen').forEach((el) => el.classList.toggle('active', el.id === 'screen-' + id));
  document.querySelectorAll('#nav button').forEach((el) => el.classList.toggle('active', el.dataset.screen === id));
}

const app = new BeastApp({ onChange: render });

const cfg = app.config;
document.getElementById('cfgRelayUrl').value = cfg.relayBaseUrl || '';
document.getElementById('cfgRelayToken').value = cfg.relayToken || '';
document.getElementById('cfgAccountId').value = cfg.accountId || '';
document.getElementById('cfgSymbol').value = cfg.symbol?.name || 'XAUUSD';

document.getElementById('btnSaveConfig').onclick = () => {
  app.updateConfig({
    relayBaseUrl: document.getElementById('cfgRelayUrl').value.trim(),
    relayToken: document.getElementById('cfgRelayToken').value.trim(),
    accountId: document.getElementById('cfgAccountId').value.trim(),
    symbol: { ...cfg.symbol, name: document.getElementById('cfgSymbol').value.trim() || 'XAUUSD' },
  });
};
document.getElementById('btnTestConn').onclick = async () => {
  const box = document.getElementById('connTestResult');
  box.textContent = 'جارٍ الاختبار...';
  const r = await app.testConnection();
  box.textContent = r.ok ? '✅ متصل بنجاح' : '❌ فشل: ' + r.reason;
};

document.getElementById('btnDemo').onclick = () => app.setMode('DEMO');
document.getElementById('btnLive').onclick = () => { document.getElementById('liveModal').classList.add('active'); };
document.getElementById('btnLiveCancel').onclick = () => { document.getElementById('liveModal').classList.remove('active'); };
document.getElementById('btnLiveConfirm').onclick = () => {
  const typed = document.getElementById('liveConfirmInput').value.trim();
  const r = app.setMode('LIVE', {
    typedConfirmation: typed,
    liveChecks: { demoGate: true, connectionTest: app.watchdog.state !== 'LOST', accountVerified: !!app.liveAccount, symbolVerified: true, executionVerified: true, riskVerified: true },
  });
  if (r.ok) document.getElementById('liveModal').classList.remove('active');
  else alert('تعذّر تفعيل LIVE: ' + r.reason);
};

document.getElementById('btnStart').onclick = () => app.startEngine();
document.getElementById('btnStop').onclick = () => app.stopEngine();
document.getElementById('btnEmergency').onclick = () => {
  if (confirm('تأكيد: إغلاق كل شيء فوراً؟')) app.emergencyKill();
};

function render(state) {
  document.getElementById('modeLabel').textContent = state.mode === 'LIVE' ? 'LIVE 🔒' : 'DEMO / PAPER';
  document.getElementById('acctLabel').textContent = state.account?.id || '—';
  document.getElementById('equityLabel').textContent = state.account?.equity != null ? `${state.account.equity} ${state.account.currency || ''}` : '—';
  document.getElementById('watchdogLabel').textContent = state.watchdog;
  document.getElementById('watchdogLabel').className = state.watchdog === 'HEALTHY' ? 'ok' : (state.watchdog === 'DEGRADED' ? 'warn' : 'danger');
  document.getElementById('statusLine').textContent = state.killSwitch.emergency ? 'EMERGENCY STOP'
    : state.killSwitch.stopped ? 'SAFE / STOPPED'
    : state.running ? 'ARMED / OPERATIONAL' : 'SAFE / WAITING';

  const ls = state.lastScan;
  document.getElementById('lastScanBox').textContent = ls
    ? `آخر محاولة مسح: ${new Date(ls.ts).toLocaleTimeString('ar')} — بيانات شموع: ${ls.hasCandles ? 'نعم' : 'لا'}`
    : 'لا يوجد مسح بعد.';

  document.getElementById('scannerBox').innerHTML = state.lastScan?.scanResult
    ? `<div>السبب: ${state.lastScan.scanResult.reason || '—'}</div>
       <div>H4 Regime: ${state.lastScan.scanResult.h4?.regime?.regime || '—'} | H1: ${state.lastScan.scanResult.h1?.regime?.regime || '—'} | M15: ${state.lastScan.scanResult.m15?.regime?.regime || '—'}</div>
       ${state.lastCandidate ? `<div class="ok">مرشح: ${state.lastCandidate.side} — Grade ${state.lastCandidate.grade} — Entry ${state.lastCandidate.entry} SL ${state.lastCandidate.stop} TP ${state.lastCandidate.target}</div>` : ''}`
    : 'لا يوجد بيانات مسح بعد — تأكد من إعداد الاتصال في الإعدادات.';

  const positions = state.positions || [];
  document.getElementById('positionsBox').innerHTML = positions.length
    ? `<table><tr><th>الرمز</th><th>الاتجاه</th><th>الحجم</th><th>الدخول</th><th>الوقف</th><th>الحالة</th></tr>` +
      positions.map((p) => `<tr><td>${p.symbol || ''}</td><td>${p.side || ''}</td><td>${p.lot || ''}</td><td>${p.entry || ''}</td><td>${p.stop || ''}</td><td>${p.state || ''}</td></tr>`).join('') +
      `</table>`
    : '<div class="small">لا توجد مراكز مفتوحة.</div>';

  const j = state.journal || [];
  document.getElementById('journalBox').innerHTML = j.length
    ? j.map((e) => `<div class="small"><span class="tag ${e.category}">${e.category}</span> ${new Date(e.ts).toLocaleTimeString('ar')} — ${e.message}</div>`).join('')
    : '<div class="small">لا توجد أحداث بعد.</div>';

  const s = state.journalStats;
  document.getElementById('statsBox').innerHTML = s
    ? `<div>إجمالي الأحداث: ${s.totalEvents}</div><div>عدد الصفقات: ${s.totalTrades}</div><div>أرباح: ${s.wins} / خسائر: ${s.losses}</div><div>نسبة الفوز: ${s.winRatePct != null ? s.winRatePct + '%' : '—'}</div>`
    : '—';

  document.getElementById('diagBox').innerHTML = `
    <div>Bridge مُهيّأ: ${state.bridgeConfigured ? 'نعم' : 'لا'}</div>
    <div>حالة المراقبة (Watchdog): ${state.watchdog}</div>
    <div>Kill Switch: ${state.killSwitch.stopped ? 'موقوف' : 'نشط'} ${state.killSwitch.emergency ? '(طوارئ)' : ''}</div>
    <div>LIVE مفتوح: ${state.liveUnlocked ? 'نعم' : 'لا'}</div>`;
}

render(app.getState());
