/* TASko BEAST — relay/bridge HTTP client.
   Thin wrapper around fetch() for talking to server/relay.js. All real
   broker execution still happens on the MT5 side (mt5/TASko_BEAST_Bridge.mq5);
   this module only queues idempotent, versioned commands and reads back
   results/status. It never talks to a broker directly and never embeds
   credentials beyond the relay bridge token supplied by the person. */

import { retry } from './reliability.js';

export class BridgeClient {
  constructor({ baseUrl, token, accountId, fetchImpl = (typeof fetch !== 'undefined' ? fetch : null) }) {
    if (!baseUrl) throw new Error('MISSING_RELAY_BASE_URL');
    if (!fetchImpl) throw new Error('NO_FETCH_IMPLEMENTATION');
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.token = token;
    this.accountId = accountId;
    this.fetch = fetchImpl;
  }

  _headers() {
    const h = { 'content-type': 'application/json' };
    if (this.token) h.authorization = `Bearer ${this.token}`;
    return h;
  }

  async health() {
    const r = await this.fetch(`${this.baseUrl}/health`, { headers: this._headers() });
    if (!r.ok) throw new Error(`RELAY_HEALTH_HTTP_${r.status}`);
    return r.json();
  }

  async sendCommand(command) {
    return retry(async () => {
      const r = await this.fetch(`${this.baseUrl}/command`, {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify(command),
      });
      if (!r.ok) throw new Error(`RELAY_COMMAND_HTTP_${r.status}`);
      return r.json();
    }, { attempts: 3 });
  }

  async getResult(clientCommandId) {
    const r = await this.fetch(`${this.baseUrl}/result?command=${encodeURIComponent(clientCommandId)}`, {
      headers: this._headers(),
    });
    if (!r.ok) throw new Error(`RELAY_RESULT_HTTP_${r.status}`);
    return r.json();
  }

  async getStatus() {
    const r = await this.fetch(`${this.baseUrl}/status?account=${encodeURIComponent(this.accountId)}`, {
      headers: this._headers(),
    });
    if (!r.ok) throw new Error(`RELAY_STATUS_HTTP_${r.status}`);
    return r.json();
  }

  /* Polls /result until the EA has answered or timeoutMs elapses. Used
     for read commands (GET_ACCOUNT, GET_TICK, GET_CANDLES, ...) where the
     app needs the answer before continuing the scan cycle. */
  async waitForResult(clientCommandId, { timeoutMs = 15000, pollMs = 500 } = {}) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const res = await this.getResult(clientCommandId);
      if (res) return res;
      await new Promise((r) => setTimeout(r, pollMs));
    }
    return null;
  }

  async sendAndWait(command, opts) {
    await this.sendCommand(command);
    return this.waitForResult(command.clientCommandId, opts);
  }
}
