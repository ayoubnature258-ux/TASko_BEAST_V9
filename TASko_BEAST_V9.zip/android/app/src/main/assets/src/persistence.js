/* TASko BEAST — state persistence.
   safeJson() and MemoryStateStore are unchanged from v5.4 (used by the
   existing test suite). LocalStorageStateStore is new: it is what the
   real WebView app uses so open positions, journal entries and the
   protection ladder survive an app restart/reload instead of vanishing
   the moment the process is killed. */

export function safeJson(value) {
  return JSON.stringify(value, (key, v) => (
    /password|secret|token|api.?key|private.?key/i.test(String(key)) ? '[REDACTED]' : v
  ));
}

export class MemoryStateStore {
  constructor() { this.data = null; }
  save(state) { this.data = structuredClone(state); return true; }
  load() { return this.data ? structuredClone(this.data) : null; }
  clear() { this.data = null; }
}

export class LocalStorageStateStore {
  constructor(key = 'tasko_beast_state_v1') {
    this.key = key;
    this.available = LocalStorageStateStore.probe();
  }
  static probe() {
    try {
      if (typeof localStorage === 'undefined') return false;
      const probeKey = '__tasko_probe__';
      localStorage.setItem(probeKey, '1');
      localStorage.removeItem(probeKey);
      return true;
    } catch {
      return false;
    }
  }
  save(state) {
    if (!this.available) return false;
    try {
      localStorage.setItem(this.key, safeJson(state));
      return true;
    } catch {
      return false;
    }
  }
  load() {
    if (!this.available) return null;
    try {
      const raw = localStorage.getItem(this.key);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }
  clear() {
    if (!this.available) return;
    try { localStorage.removeItem(this.key); } catch { /* best-effort */ }
  }
}

/* Picks LocalStorage when it is actually available (browser/WebView) and
   silently falls back to an in-memory store (Node/tests/private-mode with
   storage disabled) so calling code never has to branch on environment. */
export function createDefaultStore(key) {
  const ls = new LocalStorageStateStore(key);
  return ls.available ? ls : new MemoryStateStore();
}
