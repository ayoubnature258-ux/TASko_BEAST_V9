/* TASko BEAST — journal & logs.
   Previously the "Journal / Full Log" screens were just static labels
   with nothing behind them. This module is a small, persistent,
   append-only event log used by app.js for every decision, order,
   protection change, connection event and system message, and backs
   the Journal / Full Log / Diagnostics screens with real data. */

const MAX_ENTRIES = 5000;
const CATEGORIES = ['TRADE', 'RISK', 'SYSTEM', 'CONNECTION', 'SCAN'];

export class Journal {
  constructor(store) {
    this.store = store;
    this.entries = this._load();
  }

  _load() {
    try {
      const saved = this.store?.load?.();
      return Array.isArray(saved?.journal) ? saved.journal : [];
    } catch {
      return [];
    }
  }

  _persist() {
    try {
      const existing = this.store?.load?.() || {};
      this.store?.save?.({ ...existing, journal: this.entries });
    } catch {
      /* persistence is best-effort; the journal simply stays in memory */
    }
  }

  log(category, message, data = {}) {
    const cat = CATEGORIES.includes(category) ? category : 'SYSTEM';
    const entry = { ts: Date.now(), category: cat, message, data };
    this.entries.push(entry);
    if (this.entries.length > MAX_ENTRIES) this.entries.splice(0, this.entries.length - MAX_ENTRIES);
    this._persist();
    return entry;
  }

  trade(message, data) { return this.log('TRADE', message, data); }
  risk(message, data) { return this.log('RISK', message, data); }
  system(message, data) { return this.log('SYSTEM', message, data); }
  connection(message, data) { return this.log('CONNECTION', message, data); }
  scan(message, data) { return this.log('SCAN', message, data); }

  recent(n = 100) { return this.entries.slice(-n).reverse(); }
  byCategory(category, n = 100) { return this.entries.filter((e) => e.category === category).slice(-n).reverse(); }

  stats() {
    const trades = this.entries.filter((e) => e.category === 'TRADE');
    const wins = trades.filter((e) => e.data?.result === 'WIN').length;
    const losses = trades.filter((e) => e.data?.result === 'LOSS').length;
    const closed = wins + losses;
    return {
      totalEvents: this.entries.length,
      totalTrades: trades.length,
      wins,
      losses,
      winRatePct: closed > 0 ? Number(((wins / closed) * 100).toFixed(2)) : null,
    };
  }

  clear() { this.entries = []; this._persist(); }
}
