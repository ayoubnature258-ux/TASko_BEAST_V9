/* Opportunity expansion: improves candidate coverage without lowering the A/A+ gate. */
export const OPPORTUNITY_RULES=Object.freeze({
  grades:['A+','A'],
  minConfidence:0.70,
  maxCandidatesPerScan:100,
  requireCompleteLevels:true
});
const finite=Number.isFinite;
export function normalizeCandidate(c){
  if(!c||typeof c!=='object') return null;
  const grade=c.grade==='A+'?'A+':c.grade==='A'?'A':null;
  if(!grade||!finite(c.entry)||!finite(c.stop)||!finite(c.target)) return null;
  const confirmation=c.confirmation===true;
  const confidence=finite(c.confidence)?Math.max(0,Math.min(1,c.confidence)):null;
  if(!confirmation||!OPPORTUNITY_RULES.requireCompleteLevels) return null;
  if(confidence!==null&&confidence<OPPORTUNITY_RULES.minConfidence)return null;
  return {...c,grade,confidence};
}
export function scanOpportunities(candidates,{maxCandidates=OPPORTUNITY_RULES.maxCandidates}={}){
  const list=Array.isArray(candidates)?candidates:[];
  const valid=list.map(normalizeCandidate).filter(Boolean).sort((a,b)=>
    (b.grade==='A+'?2:1)-(a.grade==='A+'?2:1) || (b.edge??-Infinity)-(a.edge??-Infinity) || (b.confidence??0)-(a.confidence??0)
  );
  return valid.slice(0,maxCandidates);
}
