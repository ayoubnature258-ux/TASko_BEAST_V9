/* TASko BEAST — connection watchdog & smart disconnection recovery.

   Design note on where responsibility lives:
   The MT5 EA (mt5/TASko_BEAST_Bridge.mq5) stays connected to the broker
   even when this app/phone loses network entirely, so the EA itself is
   the primary, local line of defense (every order already carries a
   broker-side SL the moment it is opened, and the EA re-verifies that
   SL is present on every timer tick — see the EA's EnsureProtectiveStop
   routine). This module is the *app-side* watchdog: it tracks whether
   the app can still reach the relay/EA at all, and — only when it still
   has a path to the relay — proactively queues a defensive command
   batch (cancel/close) that the EA will apply the instant it reconnects.
   It never claims to protect a position across a total loss of the
   app's own network path; the EA's own local stop is what protects
   money in that case. */

export const WATCHDOG_STATES = ['HEALTHY', 'DEGRADED', 'LOST'];

export class ConnectionWatchdog {
  constructor({ degradedAfterMs = 10000, lostAfterMs = 30000, onStateChange } = {}) {
    this.degradedAfterMs = degradedAfterMs;
    this.lostAfterMs = lostAfterMs;
    this.onStateChange = onStateChange || (() => {});
    this.lastSeenAt = null;
    this.state = 'LOST';
  }

  heartbeat(now = Date.now()) {
    this.lastSeenAt = now;
    this._setState('HEALTHY');
  }

  evaluate(now = Date.now()) {
    if (this.lastSeenAt == null) {
      this._setState('LOST');
      return this.state;
    }
    const age = now - this.lastSeenAt;
    if (age >= this.lostAfterMs) this._setState('LOST');
    else if (age >= this.degradedAfterMs) this._setState('DEGRADED');
    else this._setState('HEALTHY');
    return this.state;
  }

  _setState(next) {
    if (next === this.state) return;
    const prev = this.state;
    this.state = next;
    this.onStateChange(next, prev);
  }
}

/* Builds the defensive command batch to queue once the watchdog declares
   the bridge LOST: a CLOSE_POSITION for every open position this app
   currently knows about. The relay queues these durably; the EA applies
   them the instant it polls again after reconnecting. */
export function buildDefensiveCommands(positions, { accountId, makeId } = {}) {
  const id = makeId || (() => `wd-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  return (positions || [])
    .filter((p) => p.state !== 'EXITED')
    .map((p) => ({
      clientCommandId: id(),
      accountId,
      command: 'CLOSE_POSITION',
      protocolVersion: 1,
      ticket: p.brokerOrderId || p.id,
      reason: 'WATCHDOG_CONNECTION_LOST',
    }));
}
