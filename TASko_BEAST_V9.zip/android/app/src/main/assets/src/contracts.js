/* TASko BEAST — command protocol.
   Envelope rules (validateCommand) are unchanged from v5.4 so existing
   integrations and tests keep working. validateCommandPayload() is new:
   it checks the fields each specific command actually needs before the
   command is ever queued for the MT5 bridge, so a malformed order can
   never reach the relay in the first place. */

export const PROTOCOL_VERSION = 1;

export const COMMANDS = Object.freeze([
  'PING',
  'GET_ACCOUNT',
  'GET_POSITIONS',
  'GET_ORDERS',
  'GET_TICK',
  'GET_CANDLES',
  'CHECK_ORDER',
  'MARKET',
  'MODIFY_POSITION',
  'CLOSE_POSITION',
]);

const finite = Number.isFinite;

export function validId(x, max = 128) {
  return typeof x === 'string' && x.length > 0 && x.length <= max;
}

export function validateCommand(x) {
  return !!x
    && validId(x.clientCommandId)
    && validId(x.accountId, 64)
    && COMMANDS.includes(x.command)
    && x.protocolVersion === PROTOCOL_VERSION;
}

/* Per-command field validation. Returns {ok:true} or {ok:false, reason}. */
export function validateCommandPayload(x) {
  if (!validateCommand(x)) return { ok: false, reason: 'INVALID_ENVELOPE' };
  switch (x.command) {
    case 'PING':
    case 'GET_ACCOUNT':
    case 'GET_POSITIONS':
    case 'GET_ORDERS':
      return { ok: true };

    case 'GET_TICK':
      return validId(x.symbol) ? { ok: true } : { ok: false, reason: 'MISSING_SYMBOL' };

    case 'GET_CANDLES': {
      if (!validId(x.symbol)) return { ok: false, reason: 'MISSING_SYMBOL' };
      const tf = ['H4', 'H1', 'M15'];
      if (!Array.isArray(x.timeframes) || !x.timeframes.every((t) => tf.includes(t))) {
        return { ok: false, reason: 'INVALID_TIMEFRAMES' };
      }
      if (!finite(x.count) || x.count <= 0 || x.count > 500) return { ok: false, reason: 'INVALID_COUNT' };
      return { ok: true };
    }

    case 'CHECK_ORDER':
      return validId(String(x.ticket ?? '')) ? { ok: true } : { ok: false, reason: 'MISSING_TICKET' };

    case 'MARKET':
      if (!validId(x.symbol)) return { ok: false, reason: 'MISSING_SYMBOL' };
      if (x.side !== 'BUY' && x.side !== 'SELL') return { ok: false, reason: 'INVALID_SIDE' };
      if (!finite(x.volume) || x.volume <= 0) return { ok: false, reason: 'INVALID_VOLUME' };
      if (!finite(x.sl) || x.sl <= 0) return { ok: false, reason: 'MISSING_STOP_LOSS' };
      if (!finite(x.tp) || x.tp <= 0) return { ok: false, reason: 'MISSING_TAKE_PROFIT' };
      return { ok: true };

    case 'MODIFY_POSITION':
      if (!validId(String(x.ticket ?? ''))) return { ok: false, reason: 'MISSING_TICKET' };
      if (!finite(x.sl) && !finite(x.tp)) return { ok: false, reason: 'NOTHING_TO_MODIFY' };
      return { ok: true };

    case 'CLOSE_POSITION':
      return validId(String(x.ticket ?? '')) ? { ok: true } : { ok: false, reason: 'MISSING_TICKET' };

    default:
      return { ok: false, reason: 'UNKNOWN_COMMAND' };
  }
}

/* Builds a fresh, protocol-valid command envelope merged with payload
   fields, so callers never hand-roll clientCommandId/protocolVersion. */
export function buildCommand(accountId, command, payload = {}, idFactory) {
  const makeId = idFactory
    || (() => `${command.toLowerCase()}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  return { clientCommandId: makeId(), accountId, command, protocolVersion: PROTOCOL_VERSION, ...payload };
}
