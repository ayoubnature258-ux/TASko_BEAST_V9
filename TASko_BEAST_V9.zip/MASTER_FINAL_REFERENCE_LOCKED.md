# TASko BEAST — MASTER FINAL REFERENCE — LOCKED — FINAL

STATUS: LOCKED 🔒

This package treats the user's supplied MASTER FINAL REFERENCE as the source of truth. The implementation is separated from the reference so implementation changes cannot silently rewrite the master law.

Core invariants preserved in this build:
- Central Decision Engine; no forced trades; A+ then A only; UNKNOWN → NO TRADE.
- Eligibility → Account/Connection → Data → Integrity → Market State → Structure/Liquidity/Context → Edge → Opportunity → Confirmation → Risk → Position Size → Execution → Manage → Protect → Exit → Evaluate.
- Risk Gate, Capital Protection, Count Guardian, Kill Switch, Emergency Kill Switch.
- No Martingale, no random doubling, no increasing lot after losses.
- Smart Breathing and monotonic protection ladder: Part 1 → Part 2 → Full Profit → Above Full → BE.
- Demo/Paper first; Demo → Live changes the connected account, not the core engine.
- Live Activation Lock; manual activation and safety checks required.
- Persistent connection/reconnect/reconciliation and broker adapter separation.
- No credentials/secrets in app code.
- Version flow: MASTER ORIGINAL → DEVELOPMENT → TEST BUILD → LAST KNOWN GOOD → RELEASE.

IMPORTANT: The Kotlin reference supplied in the conversation remains the authoritative verbatim master document. This file is a lock/index, not a rewritten replacement for that source document.
