#property strict
#property version "9.0"
/* TASko BEAST — MT5 Bridge EA.

   Responsibilities:
   - Poll the relay for one queued command at a time and execute it.
   - Report results back to the relay (/result).
   - Serve read-only market/account/position data the app needs to scan
     and manage positions (GET_TICK, GET_CANDLES, GET_ACCOUNT, GET_POSITIONS).
   - Execute MARKET orders, and now also MODIFY_POSITION / CLOSE_POSITION
     (v5.x only handled MARKET — this was a real functional gap).
   - Post a heartbeat (/status) every tick so the app-side watchdog can
     tell whether this EA/terminal is still alive.
   - Keep a local memory of the stop-loss it last set for every ticket it
     manages, and re-apply that stop if it is ever found missing on a
     managed position — this is the EA's own local defense, independent
     of whether the app/phone is currently connected to anything, because
     the EA stays connected to the broker even when the app does not.

   Safety defaults unchanged from v5.2: AllowTrading=false until the
   person explicitly arms it, and every WebRequest destination must be
   allow-listed in Tools -> Options -> Expert Advisors in the terminal. */

#include <Trade/Trade.mqh>
CTrade trade;

input ulong   TASkoMagic   = 26092026;
input bool    AllowTrading = false;               // SAFE DEFAULT: false
input string  RelayBaseUrl = "http://127.0.0.1:8787";
input string  BridgeToken  = "";
input int     PollMs       = 1000;
input int     CandleCount  = 120;

//--- local memory of stops we set, so we can re-apply them if removed ---
ulong  g_tickets[];
double g_knownSl[];

string H() { return "Authorization: Bearer " + BridgeToken + "\r\nContent-Type: application/json\r\n"; }
string A() { return IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN)); }
bool   CanTrade() { return AllowTrading && TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) && MQLInfoInteger(MQL_TRADE_ALLOWED); }

string E(string s) { StringReplace(s, "\\", "\\\\"); StringReplace(s, "\"", "\\\""); return s; }

string J(string s, string k) {
  string p = "\"" + k + "\":"; int a = StringFind(s, p);
  if (a < 0) return "";
  a += StringLen(p);
  while (a < StringLen(s) && (StringGetCharacter(s, a) == ' ' || StringGetCharacter(s, a) == '\t')) a++;
  if (a >= StringLen(s) || StringGetCharacter(s, a) != '"') return "";
  int b = a + 1;
  while (b < StringLen(s)) { if (StringGetCharacter(s, b) == '"' && StringGetCharacter(s, b - 1) != '\\') break; b++; }
  return b < StringLen(s) ? StringSubstr(s, a + 1, b - a - 1) : "";
}

double N(string s, string k) {
  string p = "\"" + k + "\":"; int a = StringFind(s, p);
  if (a < 0) return EMPTY_VALUE;
  a += StringLen(p);
  while (a < StringLen(s) && (StringGetCharacter(s, a) == ' ' || StringGetCharacter(s, a) == '\t')) a++;
  int b = a;
  while (b < StringLen(s)) {
    int c = StringGetCharacter(s, b);
    if ((c >= '0' && c <= '9') || c == '-' || c == '.' || c == 'e' || c == 'E' || c == '+') b++; else break;
  }
  return StringToDouble(StringSubstr(s, a, b - a));
}

//--- known-SL memory (linear arrays; position counts here are small) ---
void SetKnownSl(ulong ticket, double sl) {
  for (int i = 0; i < ArraySize(g_tickets); i++) if (g_tickets[i] == ticket) { g_knownSl[i] = sl; return; }
  int n = ArraySize(g_tickets);
  ArrayResize(g_tickets, n + 1); ArrayResize(g_knownSl, n + 1);
  g_tickets[n] = ticket; g_knownSl[n] = sl;
}
double GetKnownSl(ulong ticket) {
  for (int i = 0; i < ArraySize(g_tickets); i++) if (g_tickets[i] == ticket) return g_knownSl[i];
  return 0;
}
void ForgetTicket(ulong ticket) {
  for (int i = 0; i < ArraySize(g_tickets); i++) {
    if (g_tickets[i] == ticket) {
      for (int k = i; k < ArraySize(g_tickets) - 1; k++) { g_tickets[k] = g_tickets[k + 1]; g_knownSl[k] = g_knownSl[k + 1]; }
      ArrayResize(g_tickets, ArraySize(g_tickets) - 1); ArrayResize(g_knownSl, ArraySize(g_knownSl) - 1);
      return;
    }
  }
}

//--- HTTP -----------------------------------------------------------------
bool Post(string path, string body, string &out) {
  char data[], outb[]; string rh;
  StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
  ResetLastError();
  int code = WebRequest("POST", RelayBaseUrl + path, H(), 5000, data, outb, rh);
  out = CharArrayToString(outb, 0, -1, CP_UTF8);
  return code >= 200 && code < 300;
}
bool Get(string path, string &out) {
  char data[], outb[]; string rh;
  ResetLastError();
  int code = WebRequest("GET", RelayBaseUrl + path, H(), 5000, data, outb, rh);
  out = CharArrayToString(outb, 0, -1, CP_UTF8);
  return code >= 200 && code < 300;
}
void Result(string cid, bool ok, string reason, string extra = "") {
  string body = "{\"accountId\":\"" + A() + "\",\"clientCommandId\":\"" + E(cid) + "\",\"ok\":" + (ok ? "true" : "false")
              + ",\"reason\":\"" + E(reason) + "\"" + (extra == "" ? "" : "," + extra) + "}";
  string dummy; Post("/result", body, dummy);
}

//--- execution --------------------------------------------------------------
bool ExecuteMarket(string symbol, string side, double volume, double sl, double tp, string cid, ulong &outTicket) {
  outTicket = 0;
  if (!CanTrade()) return false;
  if (!SymbolSelect(symbol, true)) return false;
  double vmin = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN), vmax = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX), vstep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
  if (volume < vmin || volume > vmax || vstep <= 0) return false;
  volume = MathFloor(volume / vstep + 1e-9) * vstep;
  trade.SetExpertMagicNumber(TASkoMagic);
  trade.SetAsyncMode(false);
  bool ok = side == "BUY" ? trade.Buy(volume, symbol, 0, sl, tp, cid) : trade.Sell(volume, symbol, 0, sl, tp, cid);
  if (ok) { outTicket = trade.ResultOrder(); SetKnownSl(outTicket, sl); }
  return ok;
}

bool FindPositionBySpec(string ticketStr, ulong &ticket) {
  ticket = (ulong)StringToInteger(ticketStr);
  return PositionSelectByTicket(ticket) && PositionGetInteger(POSITION_MAGIC) == (long)TASkoMagic;
}

bool ModifyPositionCmd(string ticketStr, double sl, double tp) {
  if (!CanTrade()) return false;
  ulong ticket; if (!FindPositionBySpec(ticketStr, ticket)) return false;
  double curSl = PositionGetDouble(POSITION_SL), curTp = PositionGetDouble(POSITION_TP);
  double newSl = (sl == EMPTY_VALUE || sl <= 0) ? curSl : sl;
  double newTp = (tp == EMPTY_VALUE || tp <= 0) ? curTp : tp;
  bool ok = trade.PositionModify(ticket, newSl, newTp);
  if (ok) SetKnownSl(ticket, newSl);
  return ok;
}

bool ClosePositionCmd(string ticketStr) {
  if (!CanTrade()) return false;
  ulong ticket; if (!FindPositionBySpec(ticketStr, ticket)) return false;
  bool ok = trade.PositionClose(ticket);
  if (ok) ForgetTicket(ticket);
  return ok;
}

//--- read-only responders -----------------------------------------------
void RespondAccount(string cid) {
  double bal = AccountInfoDouble(ACCOUNT_BALANCE), eq = AccountInfoDouble(ACCOUNT_EQUITY);
  double marginUsed = AccountInfoDouble(ACCOUNT_MARGIN), marginFree = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
  double marginUsagePct = eq > 0 ? (marginUsed / eq * 100.0) : 0;
  double freeMarginPct = eq > 0 ? (marginFree / eq * 100.0) : 0;
  bool canTrade = AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) && TerminalInfoInteger(TERMINAL_TRADE_ALLOWED);
  string acc = "\"account\":{\"id\":\"" + A() + "\",\"type\":\"" + (AllowTrading ? "LIVE" : "DEMO")
    + "\",\"connectionStatus\":\"VERIFIED\",\"balance\":" + DoubleToString(bal, 2)
    + ",\"equity\":" + DoubleToString(eq, 2) + ",\"currency\":\"" + AccountInfoString(ACCOUNT_CURRENCY)
    + "\",\"canTrade\":" + (canTrade ? "true" : "false") + ",\"drawdownPct\":0"
    + ",\"marginUsagePct\":" + DoubleToString(marginUsagePct, 2) + ",\"freeMarginPct\":" + DoubleToString(freeMarginPct, 2) + "}";
  Result(cid, true, "OK", acc);
}

void RespondPositions(string cid) {
  string arr = "[";
  int total = PositionsTotal();
  bool first = true;
  for (int i = 0; i < total; i++) {
    ulong ticket = PositionGetTicket(i);
    if (!PositionSelectByTicket(ticket)) continue;
    if (PositionGetInteger(POSITION_MAGIC) != (long)TASkoMagic) continue;
    if (!first) arr += ",";
    first = false;
    long type = PositionGetInteger(POSITION_TYPE);
    arr += "{\"ticket\":\"" + IntegerToString((long)ticket) + "\""
      + ",\"symbol\":\"" + PositionGetString(POSITION_SYMBOL) + "\""
      + ",\"side\":\"" + (type == POSITION_TYPE_BUY ? "BUY" : "SELL") + "\""
      + ",\"lot\":" + DoubleToString(PositionGetDouble(POSITION_VOLUME), 2)
      + ",\"entry\":" + DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 8)
      + ",\"stop\":" + DoubleToString(PositionGetDouble(POSITION_SL), 8)
      + ",\"target\":" + DoubleToString(PositionGetDouble(POSITION_TP), 8)
      + ",\"state\":\"ENTERED\"}";
  }
  arr += "]";
  Result(cid, true, "OK", "\"positions\":" + arr);
}

void RespondTick(string cid, string symbol) {
  MqlTick t;
  if (symbol == "" || !SymbolInfoTick(symbol, t) || t.bid <= 0 || t.ask < t.bid) { Result(cid, false, "NO_TICK"); return; }
  double spread = (t.ask - t.bid) / SymbolInfoDouble(symbol, SYMBOL_POINT);
  string tick = "\"tick\":{\"bid\":" + DoubleToString(t.bid, 8) + ",\"ask\":" + DoubleToString(t.ask, 8)
    + ",\"timestamp\":" + IntegerToString((long)t.time_msc) + ",\"integrity\":true"
    + ",\"spread\":" + DoubleToString(spread, 2) + ",\"slippage\":0,\"volatilityTicks\":0}";
  Result(cid, true, "OK", tick);
}

string TimeframeName(ENUM_TIMEFRAMES tf) { return tf == PERIOD_H4 ? "H4" : tf == PERIOD_H1 ? "H1" : "M15"; }

string CandlesJsonFor(string symbol, ENUM_TIMEFRAMES tf, int count) {
  MqlRates rates[];
  ArraySetAsSeries(rates, true);
  int copied = CopyRates(symbol, tf, 0, count, rates);
  string arr = "[";
  for (int i = copied - 1; i >= 0; i--) { // oldest -> newest, as market_scanner.js expects
    arr += "{\"time\":" + IntegerToString((long)rates[i].time)
      + ",\"open\":" + DoubleToString(rates[i].open, 8) + ",\"high\":" + DoubleToString(rates[i].high, 8)
      + ",\"low\":" + DoubleToString(rates[i].low, 8) + ",\"close\":" + DoubleToString(rates[i].close, 8) + "}";
    if (i > 0) arr += ",";
  }
  arr += "]";
  return arr;
}

void RespondCandles(string cid, string symbol, int count) {
  if (symbol == "" || !SymbolSelect(symbol, true)) { Result(cid, false, "UNKNOWN_SYMBOL"); return; }
  string payload = "\"candles\":{\"H4\":" + CandlesJsonFor(symbol, PERIOD_H4, count)
    + ",\"H1\":" + CandlesJsonFor(symbol, PERIOD_H1, count)
    + ",\"M15\":" + CandlesJsonFor(symbol, PERIOD_M15, count) + "}";
  Result(cid, true, "OK", payload);
}

//--- local protective-stop watchdog: re-apply a known SL if it vanished ---
void EnsureProtectiveStops() {
  int total = PositionsTotal();
  for (int i = 0; i < total; i++) {
    ulong ticket = PositionGetTicket(i);
    if (!PositionSelectByTicket(ticket)) continue;
    if (PositionGetInteger(POSITION_MAGIC) != (long)TASkoMagic) continue;
    double known = GetKnownSl(ticket);
    double current = PositionGetDouble(POSITION_SL);
    if (known > 0 && current == 0 && CanTrade()) {
      trade.PositionModify(ticket, known, PositionGetDouble(POSITION_TP));
    }
  }
}

//--- heartbeat --------------------------------------------------------------
void PostStatus() {
  int ours = 0, total = PositionsTotal();
  for (int i = 0; i < total; i++) {
    ulong ticket = PositionGetTicket(i);
    if (PositionSelectByTicket(ticket) && PositionGetInteger(POSITION_MAGIC) == (long)TASkoMagic) ours++;
  }
  string body = "{\"accountId\":\"" + A() + "\",\"canTrade\":" + (CanTrade() ? "true" : "false")
    + ",\"terminalConnected\":" + (TerminalInfoInteger(TERMINAL_CONNECTED) ? "true" : "false")
    + ",\"positionsManaged\":" + IntegerToString(ours) + "}";
  string dummy; Post("/status", body, dummy);
}

//--- command dispatch ---------------------------------------------------
void Dispatch(string s) {
  string cid = J(s, "clientCommandId"), acct = J(s, "accountId"), cmd = J(s, "command");
  if (acct != A() || cid == "") { Result(cid, false, "ACCOUNT_MISMATCH"); return; }

  if (cmd == "PING")           { Result(cid, true, "PONG"); return; }
  if (cmd == "GET_ACCOUNT")    { RespondAccount(cid); return; }
  if (cmd == "GET_POSITIONS")  { RespondPositions(cid); return; }
  if (cmd == "GET_TICK")       { RespondTick(cid, J(s, "symbol")); return; }
  if (cmd == "GET_CANDLES") {
    double c = N(s, "count");
    RespondCandles(cid, J(s, "symbol"), c == EMPTY_VALUE || c <= 0 ? CandleCount : (int)c);
    return;
  }

  if (cmd == "MARKET") {
    string sym = J(s, "symbol"), side = J(s, "side");
    double vol = N(s, "volume"), sl = N(s, "sl"), tp = N(s, "tp");
    if (sym == "" || (side != "BUY" && side != "SELL") || vol == EMPTY_VALUE || sl == EMPTY_VALUE || tp == EMPTY_VALUE) {
      Result(cid, false, "INVALID_ORDER_FIELDS"); return;
    }
    ulong ticket;
    bool ok = ExecuteMarket(sym, side, vol, sl, tp, cid, ticket);
    Result(cid, ok, ok ? "ORDER_SENT" : "ORDER_REJECTED", ok ? "\"ticket\":\"" + IntegerToString((long)ticket) + "\"" : "");
    return;
  }

  if (cmd == "MODIFY_POSITION") {
    string ticketStr = J(s, "ticket");
    double sl = N(s, "sl"), tp = N(s, "tp");
    bool ok = ModifyPositionCmd(ticketStr, sl, tp);
    Result(cid, ok, ok ? "MODIFIED" : "MODIFY_REJECTED");
    return;
  }

  if (cmd == "CLOSE_POSITION") {
    string ticketStr = J(s, "ticket");
    bool ok = ClosePositionCmd(ticketStr);
    Result(cid, ok, ok ? "CLOSED" : "CLOSE_REJECTED");
    return;
  }

  Result(cid, false, "UNSUPPORTED_COMMAND");
}

void Poll() {
  string url = "/poll?account=" + A();
  string s;
  if (!Get(url, s)) return;
  if (StringLen(s) < 5 || s == "null") return;
  Dispatch(s);
}

int OnInit() { EventSetMillisecondTimer(PollMs); return INIT_SUCCEEDED; }
void OnDeinit(const int reason) { EventKillTimer(); }
void OnTimer() {
  Poll();
  EnsureProtectiveStops();
  PostStatus();
  Comment("TASko BEAST Bridge V9\nAccount: ", A(), "\nServer: ", AccountInfoString(ACCOUNT_SERVER),
          "\nTrading: ", CanTrade() ? "ARMED" : "LOCKED", "\nManaged positions: ", ArraySize(g_tickets));
}
