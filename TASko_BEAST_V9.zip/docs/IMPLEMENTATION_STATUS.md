# Implementation Status — v9

## What actually works end to end now
- The WebView UI (`web/index.html` + `web/src/main.js`) is wired to a real
  application controller (`web/src/app.js`), not static placeholder text.
  The previous release's index.html contained a JS template-literal bug
  that rendered as raw `${...}` text instead of the UI — this is fixed.
- **Phase 1 — System & Safety Init**: DEMO/LIVE toggle, LIVE gated by
  `LiveSafetyGate` (6 checks) *and* a typed `CONFIRM LIVE` phrase, kill
  switch wired to a real emergency-close routine.
- **Phase 2 — Market Analysis**: `web/src/market_scanner.js` is new —
  H4 -> H1 -> M15 structure bias, swing/fractal detection, liquidity
  zones, sweep detection, break-of-structure, and ATR-based regime
  classification (TREND/RANGE/VOLATILE). This did not exist before.
- **Phase 3 — Execution & Risk Gate**: the scanner's candidate is passed
  through `opportunity.normalizeCandidate()` and then `core.centralDecision()`
  — the same tested, unchanged risk core from v5.4 remains the sole
  approval authority. DEMO executes via `PaperBroker`; LIVE sends a
  `MARKET` command through the relay to the MT5 EA.
- **Phase 4 — Position & Profit Management**: `managePosition()` (already
  tested in core.js) is now actually called every management cycle. In
  DEMO, `PaperBroker.mark()` applies it directly. In LIVE, the app tracks
  each ticket's protection stage locally, and pushes stop tightening to
  the EA via `MODIFY_POSITION` — which the EA can now actually execute
  (v5.4's EA only handled `MARKET`; this was a real gap, now closed).
- **Phase 5 — Emergency & Continuous Monitoring**:
  - `web/src/watchdog.js` (new): app-side connection watchdog
    (HEALTHY/DEGRADED/LOST) driven by the EA's new `/status` heartbeat.
    On LOST, it queues `CLOSE_POSITION` for every tracked position.
  - The EA's own local defense (`EnsureProtectiveStops()`) re-applies a
    remembered stop-loss on any of its managed positions if that stop is
    ever found missing — independent of whether the app is connected,
    because the EA stays connected to the broker even if the phone/app
    is not.
  - `web/src/journal.js` (new): persistent, categorized event log
    (TRADE/RISK/SYSTEM/CONNECTION/SCAN), backing the Journal/Stats/
    Diagnostics screens with real data instead of static labels.
  - Emergency Kill Switch button now calls `core.KillSwitch`, stops the
    engine loops, and sends real `CLOSE_POSITION` commands for every
    tracked LIVE position.

## Test status
`npm test` → 67/67 passing (46 original core/protocol/stress tests,
unchanged and still green, + 21 new tests covering the scanner, journal,
watchdog, extended contracts, the bridge client, and an app.js smoke
test).

## Explicitly NOT done / known limitations
- `mt5/TASko_BEAST_Bridge.mq5` was rewritten to add `MODIFY_POSITION`,
  `CLOSE_POSITION`, `GET_TICK`, `GET_CANDLES`, `GET_ACCOUNT`,
  `GET_POSITIONS`, the status heartbeat, and the local stop watchdog —
  but **it was not compiled**, because no MetaEditor is available in this
  environment. It must be compiled and DEMO-tested in MetaTrader before
  any use.
- `server/relay.js` remains a single-process development relay with
  periodic file-snapshot durability, not a production-grade transactional
  queue. See its header comment for the exact list of what production
  would still need (HTTPS termination, real secret store, real queue,
  replay protection beyond idempotency, rate limiting).
- Cross-symbol/cross-position correlation risk is not tracked; portfolio
  exposure is approximated conservatively and still passes through the
  same `centralDecision()` exposure gate.
- The market scanner is a deterministic, rule-based technical-structure
  scanner. It is not a proven profitable strategy, is not backtested here,
  and makes no such claim — see the header comment in `market_scanner.js`.
- No automated end-to-end test exercises the real MT5 EA or a live relay
  process together (that requires MetaTrader + a running relay, both
  outside this environment); only the JS-side logic and the relay's HTTP
  surface were exercised directly here.
