# Architecture — v9

```
web/index.html (UI shell, no logic)
  -> web/src/main.js       (DOM wiring: buttons, screens, render(state))
       -> web/src/app.js   (BeastApp: the orchestrator)
            -> web/src/market_scanner.js  (Phase 2: H4->H1->M15 structure & liquidity)
            -> web/src/opportunity.js     (A+/A candidate filter, unchanged from v5.4)
            -> web/src/core.js            (Phase 3/4: centralDecision, sizing, protection,
                                            PaperBroker, KillSwitch, LiveSafetyGate — unchanged, 46/46 tests)
            -> web/src/bridge_client.js   (HTTP client to the relay)
            -> web/src/watchdog.js        (Phase 5: connection health, defensive close)
            -> web/src/journal.js         (persistent event log)
            -> web/src/persistence.js     (LocalStorageStateStore in the WebView, MemoryStateStore in tests)
            -> web/src/contracts.js       (command envelope + per-command field validation)

server/relay.js        (HTTP command queue / result store / status board; dev-grade, see its header)
mt5/TASko_BEAST_Bridge.mq5  (the only thing that ever talks to the broker)
```

`src/` (repo root) and `android/app/src/main/assets/src/` are byte-identical
copies of `web/src/`, kept in sync because the Android WebView loads its
assets from a local `file://` root and cannot reach outside its own
package. Edit `web/src/`, then re-sync the other two copies before
building the APK.

## Data flow, one scan cycle
1. `app.js` asks the bridge for the current tick (`GET_TICK`) and recent
   H4/H1/M15 candles (`GET_CANDLES`) — both ultimately served by the MT5
   EA via `SymbolInfoTick`/`CopyRates`. There is no other market-data
   source in this app; if the bridge is unreachable the cycle is skipped
   and logged, never guessed at.
2. `market_scanner.scanMultiTimeframe()` turns those candles into at most
   one candidate (or `null` with a documented reason).
3. `opportunity.normalizeCandidate()` re-checks the candidate against the
   A+/A/confidence rules.
4. `core.centralDecision()` is the single point that approves or rejects
   the trade — against the account snapshot, the tick, the symbol spec,
   the risk config and a portfolio-exposure estimate. Nothing upstream of
   this function can force a trade through it.
5. If approved: DEMO submits to `PaperBroker` (in-app simulation against
   the same real MT5 ticks); LIVE sends a `MARKET` command through the
   relay to the EA, which is the only component that ever places a real
   order.

## Data flow, one management cycle
`core.managePosition()` (breathing stop + protection ladder, monotonic —
a stop never moves backward) runs against every open position. DEMO
applies it directly inside `PaperBroker.mark()`. LIVE computes it locally
per tracked ticket and, only if the stop actually tightened, sends
`MODIFY_POSITION` to the EA — which can now execute it (the EA previously
only understood `MARKET`).

## Why DEMO and LIVE share one engine
Switching modes only swaps which broker adapter executes an already-
approved decision (`PaperBroker` vs. a `MARKET`/`MODIFY_POSITION`/
`CLOSE_POSITION` command to the EA) and which account snapshot is read.
`centralDecision()`, the scanner, the protection ladder and the journal
are identical code paths in both modes — this is deliberate, so DEMO
behavior is actually representative of LIVE behavior.

## LIVE activation (two independent locks)
1. `LiveSafetyGate.activate()` in `core.js` — six checks (demo gate,
   connection test, account/symbol/execution/risk verified) — unchanged
   from v5.4.
2. The person must type `CONFIRM LIVE` verbatim in the UI's confirmation
   modal (`BeastApp.setMode('LIVE', {typedConfirmation, liveChecks})`).
Both must pass. Separately, the EA's own `AllowTrading` input defaults to
`false` and must be armed manually in the terminal — a third, offline
lock the app cannot override remotely.
