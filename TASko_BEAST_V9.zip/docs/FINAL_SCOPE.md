# Final Scope — v9

TASko BEAST is a DEMO-first, safety-rail-heavy trading assistant
framework: a tested risk/execution core, a rule-based multi-timeframe
market scanner, a WebView UI, and an MT5 bridge, wired together end to
end for the first time in this release.

**It is not a proven profitable trading system, and this document makes
no claim that it is.** The scanner in `market_scanner.js` is a
deterministic, transparent, rule-based technical-structure detector
(swing structure, liquidity sweeps, break-of-structure, ATR regime). It
has not been backtested or forward-tested against real market data in
this environment. Every trade it proposes still passes through
`core.centralDecision()`, which can and does reject candidates for many
independent reasons (unknown account state, stale/wide market data,
drawdown limits, exposure limits, wrong grade, missing confirmation).

## What this release changes
Previously the safety core (`core.js`, 46/46 tests passing) existed but
was completely disconnected from the shipped app — none of it ran when
the app was opened. This release adds the missing wiring
(`app.js`), the missing market scanner, the missing journal, the missing
connection watchdog, and the missing MT5-side execution paths for
position management and emergency close — see
`docs/IMPLEMENTATION_STATUS.md` for the detailed list.

## Before using this on a DEMO account
1. Open `mt5/TASko_BEAST_Bridge.mq5` in MetaEditor and compile it —
   it has not been compiled in this environment.
2. Run `server/relay.js` somewhere reachable from both the MT5 terminal
   and the phone/app, with `TASKO_BRIDGE_TOKEN` set, and put it behind
   HTTPS for anything beyond local testing.
3. Allow-list the relay URL in MT5 (Tools -> Options -> Expert Advisors).
4. Configure the relay URL, token, account ID and symbol in the app's
   Settings screen, and use "اختبار الاتصال" (Test Connection) before
   starting the engine.
5. Start in DEMO. Do not attempt LIVE until you have watched DEMO behave
   correctly across the full pipeline — scan, decision, entry, protection
   ladder, exit, journal — for a meaningful period.

## Before using this with real money
Do not, until: the EA has been compiled and tested on a DEMO account for
an extended period; the relay has been hardened per the limitations list
in `docs/IMPLEMENTATION_STATUS.md`; and you personally understand and
accept every risk parameter in `core.js`'s `DEFAULT_CONFIG`. Nothing in
this project should be treated as financial advice or a guarantee of any
trading outcome.
