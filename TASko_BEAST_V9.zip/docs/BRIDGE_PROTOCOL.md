# TASko BEAST Bridge Protocol (v9)

The Android/Web app is the controller; the MT5 terminal (EA) is the only
execution endpoint; the relay is a thin transport queue in between. The
app never talks to a broker directly.

Flow (execution/read commands):
`APP -> POST /command -> RELAY (queued per accountId) -> EA GET /poll
-> EA executes/answers -> EA POST /result -> RELAY -> APP GET /result`

Flow (liveness):
`EA POST /status (every timer tick) -> RELAY -> APP GET /status`
The app-side `ConnectionWatchdog` (web/src/watchdog.js) treats a `/status`
older than `watchdogLostMs` as LOST and queues a defensive close for every
position it still knows about — see watchdog.js for the full rationale.

## Envelope (every command)
```json
{ "clientCommandId": "string, 1-128 chars, unique per command",
  "accountId": "string, 1-64 chars, must match the MT5 account login",
  "command": "one of COMMANDS (web/src/contracts.js)",
  "protocolVersion": 1 }
```
`validateCommand()` checks this envelope. `validateCommandPayload()`
additionally checks the command-specific fields below before anything is
ever queued.

## Commands

| Command | Extra fields | Result payload |
|---|---|---|
| `PING` | — | `{ok:true, reason:"PONG"}` |
| `GET_ACCOUNT` | — | `{ok:true, account:{id,type,connectionStatus,balance,equity,currency,canTrade,drawdownPct,marginUsagePct,freeMarginPct}}` |
| `GET_POSITIONS` | — | `{ok:true, positions:[{ticket,symbol,side,lot,entry,stop,target,state}]}` (only positions carrying `TASkoMagic`) |
| `GET_TICK` | `symbol` | `{ok:true, tick:{bid,ask,timestamp,integrity,spread,slippage,volatilityTicks}}` |
| `GET_CANDLES` | `symbol`, `timeframes:["H4","H1","M15"]`, `count` (1-500) | `{ok:true, candles:{H4:[...],H1:[...],M15:[...]}}`, each candle `{time,open,high,low,close}`, oldest→newest |
| `CHECK_ORDER` | `ticket` | order/position status lookup |
| `MARKET` | `symbol`, `side:"BUY"\|"SELL"`, `volume`, `sl`, `tp` (sl/tp mandatory — no order is ever sent without both) | `{ok, reason, ticket?}` |
| `MODIFY_POSITION` | `ticket`, `sl?`, `tp?` (at least one) | `{ok, reason}` |
| `CLOSE_POSITION` | `ticket` | `{ok, reason}` |

## Safety requirements (unchanged, and now actually enforced end to end)
- Bind every command to `accountId` + `clientCommandId`; the relay rejects
  a resend of the same id as a no-op duplicate.
- `AllowTrading=false` by default in the EA until the person manually
  arms it in the terminal's EA inputs — a separate, out-of-band lock from
  the app's own LIVE toggle.
- The app's LIVE mode additionally requires `LiveSafetyGate` to pass every
  check *and* the person to type `CONFIRM LIVE` verbatim (see
  `BeastApp.setMode()`), so two independent confirmations are needed
  before a single real order can be sent.
- Queued commands expire after `TASKO_COMMAND_TTL_MS` (default 120s) —
  the relay marks them `EXPIRED` instead of ever handing a stale command
  to the EA.
- Verify account identity, symbol, volume, stops and trading permission
  before execution (`ExecuteMarket`/`ModifyPositionCmd`/`ClosePositionCmd`
  in the EA).
- Use HTTPS + a real secret store in production; `BridgeToken`/`TOKEN` are
  placeholders for development. Do not put broker credentials in app code
  — the app only ever holds a bridge token, never broker login details.
- Android cannot execute MT5 orders by itself; the MT5 terminal/EA must be
  running and connected, and the relay's WebRequest URL must be
  allow-listed in MT5 (Tools -> Options -> Expert Advisors).

## Known, documented limitations (v9)
- The relay is still a single-process development relay (see
  `server/relay.js` header comment) — periodic JSON-file snapshotting was
  added for basic durability across restarts, but this is not a
  transactional production queue.
- `mt5/TASko_BEAST_Bridge.mq5` was written and reviewed carefully but
  **could not be compiled in this environment** (no MetaEditor available).
  It must be opened and compiled in MetaEditor, and tested on a DEMO
  account, before any use.
- Cross-symbol portfolio correlation is not tracked; `app.js` uses a
  conservative placeholder (`_portfolioRisk()`) that still goes through
  the same `centralDecision()` exposure gate.
