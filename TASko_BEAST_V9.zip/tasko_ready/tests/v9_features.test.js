import test from 'node:test';
import assert from 'node:assert/strict';

import {
  findSwings, structureBias, atr, classifyRegime, liquidityZones,
  detectSweep, detectBOS, analyzeTimeframe, scanMultiTimeframe,
} from '../web/src/market_scanner.js';
import { Journal } from '../web/src/journal.js';
import { MemoryStateStore } from '../web/src/persistence.js';
import { ConnectionWatchdog, buildDefensiveCommands } from '../web/src/watchdog.js';
import { validateCommandPayload, buildCommand, COMMANDS } from '../web/src/contracts.js';
import { BridgeClient } from '../web/src/bridge_client.js';
import { BeastApp } from '../web/src/app.js';

/* ---------- market_scanner ---------- */

/* Builds a genuine higher-high/higher-low zigzag (a swing up, a shallower
   pullback, a swing up, ...) so real fractal swing points actually form —
   a strictly monotonic ramp has no interior local extrema to detect. */
function makeTrendCandles(n, { start = 100, legUp = 6, legDown = 2, noise = 0.15 } = {}) {
  const out = [];
  let price = start;
  let i = 0;
  let leg = 0;
  while (i < n) {
    const up = leg % 2 === 0;
    const steps = up ? legUp : legDown;
    const dir = up ? 1 : -1;
    for (let k = 0; k < steps && i < n; k++, i++) {
      const open = price;
      price += dir * (0.8 + Math.random() * 0.4);
      const high = Math.max(open, price) + noise + Math.random() * noise;
      const low = Math.min(open, price) - noise - Math.random() * noise;
      out.push({ time: i, open, high, low, close: price });
    }
    leg++;
  }
  return out;
}

test('findSwings finds at least one high and one low in a zigzag series', () => {
  const candles = [];
  for (let i = 0; i < 30; i++) {
    const base = 100 + Math.sin(i / 2) * 5;
    candles.push({ time: i, open: base, high: base + 1, low: base - 1, close: base });
  }
  const swings = findSwings(candles, 2);
  assert.ok(swings.some((s) => s.type === 'HIGH'));
  assert.ok(swings.some((s) => s.type === 'LOW'));
});

test('structureBias reads a clean uptrend as BULLISH', () => {
  const candles = makeTrendCandles(40);
  const swings = findSwings(candles, 2);
  const bias = structureBias(swings);
  assert.equal(bias.bias, 'BULLISH');
});

test('atr returns null with insufficient data and a positive number otherwise', () => {
  assert.equal(atr([{ high: 1, low: 1, close: 1 }], 14), null);
  const candles = makeTrendCandles(30);
  assert.ok(atr(candles, 14) > 0);
});

test('classifyRegime returns a known regime label', () => {
  const candles = makeTrendCandles(30);
  const r = classifyRegime(candles);
  assert.ok(['TREND', 'RANGE', 'VOLATILE', 'UNKNOWN'].includes(r.regime));
});

test('liquidityZones tags recent swings with a side', () => {
  const candles = makeTrendCandles(40);
  const swings = findSwings(candles, 2);
  const zones = liquidityZones(swings, 3);
  assert.ok(zones.every((z) => z.side === 'SELL_SIDE_LIQUIDITY' || z.side === 'BUY_SIDE_LIQUIDITY'));
});

test('detectSweep and detectBOS return null on flat data (no false positives)', () => {
  const flat = Array.from({ length: 20 }, (_, i) => ({ time: i, open: 100, high: 100.1, low: 99.9, close: 100 }));
  const swings = findSwings(flat, 2);
  assert.equal(detectSweep(flat, liquidityZones(swings), 'BULLISH'), null);
  assert.equal(detectBOS(flat, swings, 'BULLISH'), null);
});

test('analyzeTimeframe rejects invalid/insufficient candle arrays', () => {
  assert.equal(analyzeTimeframe(null).ok, false);
  assert.equal(analyzeTimeframe([{ open: 1 }]).ok, false);
});

test('scanMultiTimeframe returns ok:false when any timeframe lacks data', () => {
  const r = scanMultiTimeframe({ h4: null, h1: [], m15: [], symbol: { name: 'X', tickSize: 0.01 } });
  assert.equal(r.ok, false);
});

test('scanMultiTimeframe on a strong aligned uptrend produces a BUY candidate with valid levels', () => {
  const h4 = makeTrendCandles(60, { legUp: 8, legDown: 2 });
  const h1 = makeTrendCandles(60, { legUp: 8, legDown: 2 });
  const m15 = makeTrendCandles(60, { legUp: 8, legDown: 2 });
  const r = scanMultiTimeframe({ h4, h1, m15, symbol: { name: 'XAUUSD', tickSize: 0.01 } });
  assert.equal(r.ok, true);
  if (r.candidate) {
    assert.equal(r.candidate.side, 'BUY');
    assert.ok(['A', 'A+'].includes(r.candidate.grade));
    assert.ok(r.candidate.entry > r.candidate.stop);
    assert.ok(r.candidate.target > r.candidate.entry);
  }
});

/* ---------- journal ---------- */

test('journal persists entries through its store and caps history', () => {
  const store = new MemoryStateStore();
  const j = new Journal(store);
  j.trade('OPENED', { id: 1 });
  j.risk('DRAWDOWN_LIMIT');
  const j2 = new Journal(store);
  assert.equal(j2.entries.length, 2);
  assert.equal(j2.recent(1)[0].message, 'DRAWDOWN_LIMIT');
});

test('journal.stats computes win rate from TRADE entries with a result field', () => {
  const j = new Journal(new MemoryStateStore());
  j.trade('CLOSED', { result: 'WIN' });
  j.trade('CLOSED', { result: 'WIN' });
  j.trade('CLOSED', { result: 'LOSS' });
  const s = j.stats();
  assert.equal(s.wins, 2);
  assert.equal(s.losses, 1);
  assert.equal(s.winRatePct, 66.67);
});

/* ---------- watchdog ---------- */

test('watchdog transitions HEALTHY -> DEGRADED -> LOST as time passes without a heartbeat', () => {
  const events = [];
  const wd = new ConnectionWatchdog({ degradedAfterMs: 100, lostAfterMs: 300, onStateChange: (n) => events.push(n) });
  const t0 = 1000;
  wd.heartbeat(t0);
  assert.equal(wd.state, 'HEALTHY');
  assert.equal(wd.evaluate(t0 + 150), 'DEGRADED');
  assert.equal(wd.evaluate(t0 + 400), 'LOST');
  assert.deepEqual(events, ['HEALTHY', 'DEGRADED', 'LOST']);
});

test('buildDefensiveCommands produces one CLOSE_POSITION per open position, none for exited', () => {
  const positions = [{ id: 'A', state: 'ENTERED' }, { id: 'B', state: 'EXITED' }];
  const cmds = buildDefensiveCommands(positions, { accountId: 'acc1' });
  assert.equal(cmds.length, 1);
  assert.equal(cmds[0].command, 'CLOSE_POSITION');
  assert.equal(cmds[0].ticket, 'A');
});

/* ---------- contracts v2 ---------- */

test('validateCommandPayload rejects a MARKET order missing stop loss', () => {
  const cmd = buildCommand('acc1', 'MARKET', { symbol: 'XAUUSD', side: 'BUY', volume: 0.1, tp: 2000 });
  const r = validateCommandPayload(cmd);
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'MISSING_STOP_LOSS');
});

test('validateCommandPayload accepts a well-formed MARKET order', () => {
  const cmd = buildCommand('acc1', 'MARKET', { symbol: 'XAUUSD', side: 'BUY', volume: 0.1, sl: 1990, tp: 2010 });
  assert.equal(validateCommandPayload(cmd).ok, true);
});

test('validateCommandPayload rejects MODIFY_POSITION with no ticket', () => {
  const cmd = buildCommand('acc1', 'MODIFY_POSITION', { sl: 1990 });
  assert.equal(validateCommandPayload(cmd).ok, false);
});

test('validateCommandPayload accepts GET_CANDLES with valid timeframes', () => {
  const cmd = buildCommand('acc1', 'GET_CANDLES', { symbol: 'XAUUSD', timeframes: ['H4', 'H1', 'M15'], count: 100 });
  assert.equal(validateCommandPayload(cmd).ok, true);
});

test('COMMANDS includes the new market-data and position-management commands', () => {
  for (const c of ['GET_TICK', 'GET_CANDLES', 'MODIFY_POSITION', 'CLOSE_POSITION']) {
    assert.ok(COMMANDS.includes(c));
  }
});

/* ---------- bridge_client (mocked fetch) ---------- */

test('BridgeClient.sendAndWait posts the command then polls /result until it appears', async () => {
  let resultReady = false;
  const calls = [];
  const fakeFetch = async (url, opts) => {
    calls.push(url);
    if (url.includes('/command')) {
      resultReady = true;
      return { ok: true, json: async () => ({ accepted: true }) };
    }
    if (url.includes('/result')) {
      return { ok: true, json: async () => (resultReady ? { ok: true, ticket: 42 } : null) };
    }
    throw new Error('unexpected url ' + url);
  };
  const client = new BridgeClient({ baseUrl: 'http://x', accountId: 'acc1', fetchImpl: fakeFetch });
  const res = await client.sendAndWait({ clientCommandId: 'c1', accountId: 'acc1', command: 'PING', protocolVersion: 1 }, { pollMs: 1, timeoutMs: 1000 });
  assert.equal(res.ticket, 42);
});

/* ---------- app.js smoke test (no bridge configured) ---------- */

test('BeastApp can be constructed and driven end-to-end without a configured bridge', async () => {
  const changes = [];
  const app = new BeastApp({ onChange: (s) => changes.push(s) });
  assert.equal(app.mode, 'DEMO');
  const liveAttempt = app.setMode('LIVE', {});
  assert.equal(liveAttempt.ok, false);
  assert.equal(app.mode, 'DEMO');
  const start = app.startEngine();
  assert.equal(start.ok, true);
  await app.runScanCycle(); // no bridge -> should skip safely, not throw
  await app.runManagementCycle(); // no bridge -> should skip safely, not throw
  app.stopEngine();
  await app.emergencyKill();
  assert.equal(app.killSwitch.blocked(), true);
  const state = app.getState();
  assert.equal(state.mode, 'DEMO');
  assert.ok(Array.isArray(state.journal));
  assert.ok(changes.length > 0);
});

test('BeastApp.setMode LIVE requires both the safety gate and the typed confirmation phrase', () => {
  const app = new BeastApp({ onChange: () => {} });
  const checks = { demoGate: true, connectionTest: true, accountVerified: true, symbolVerified: true, executionVerified: true, riskVerified: true };
  const missingPhrase = app.setMode('LIVE', { liveChecks: checks });
  assert.equal(missingPhrase.ok, false);
  assert.equal(missingPhrase.reason, 'CONFIRMATION_PHRASE_MISMATCH');
  const ok = app.setMode('LIVE', { liveChecks: checks, typedConfirmation: 'CONFIRM LIVE' });
  assert.equal(ok.ok, true);
  assert.equal(app.mode, 'LIVE');
});
