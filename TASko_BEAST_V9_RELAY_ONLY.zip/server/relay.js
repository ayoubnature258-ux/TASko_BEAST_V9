// TASko BEAST — relay (command queue / result store / status board).
// Still a development-grade relay: single process, no clustering, no
// durable transactional queue. What changed from v5.4:
//  - Queued commands now expire (COMMAND_TTL_MS) so a stale command from
//    an earlier session can never be executed hours later just because
//    the EA happened to reconnect and poll it off the queue.
//  - State is snapshotted to a local JSON file periodically and on
//    shutdown, and reloaded on startup, so a relay restart does not
//    silently lose in-flight commands/results the way a pure in-memory
//    Map did before.
// Production still needs: HTTPS termination in front of this process,
// a real auth/secret store, a durable transactional queue (e.g. a small
// database), replay protection beyond simple idempotency, and per-account
// rate limiting. None of that is implemented here — this is a relay
// suitable for development and controlled DEMO testing, not a hardened
// production service.

import http from 'node:http';
import fs from 'node:fs';

const PORT = Number(process.env.PORT || 8787);
const TOKEN = process.env.TASKO_BRIDGE_TOKEN;
const STATE_FILE = process.env.TASKO_RELAY_STATE_FILE || './relay_state.json';
const COMMAND_TTL_MS = Number(process.env.TASKO_COMMAND_TTL_MS || 120000);
const SNAPSHOT_INTERVAL_MS = 5000;

if (!TOKEN) console.warn('WARNING: TASKO_BRIDGE_TOKEN is not set; local development only.');

const queues = new Map();   // accountId -> [command,...]
const results = new Map();  // clientCommandId -> result
const statuses = new Map(); // accountId -> last status

function loadSnapshot() {
  try {
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    for (const [k, v] of Object.entries(parsed.queues || {})) queues.set(k, v);
    for (const [k, v] of Object.entries(parsed.results || {})) results.set(k, v);
    for (const [k, v] of Object.entries(parsed.statuses || {})) statuses.set(k, v);
    console.log(`Relay state restored from ${STATE_FILE}`);
  } catch {
    // No snapshot yet, or it is unreadable — start clean. This is a dev
    // relay; losing an empty/corrupt snapshot is not a safety issue.
  }
}
function saveSnapshot() {
  try {
    const data = {
      queues: Object.fromEntries(queues), results: Object.fromEntries(results), statuses: Object.fromEntries(statuses),
    };
    fs.writeFileSync(STATE_FILE, JSON.stringify(data));
  } catch (e) {
    console.warn('Relay snapshot failed:', e.message);
  }
}
loadSnapshot();
const snapshotTimer = setInterval(saveSnapshot, SNAPSHOT_INTERVAL_MS);
process.on('SIGINT', () => { saveSnapshot(); process.exit(0); });
process.on('SIGTERM', () => { saveSnapshot(); process.exit(0); });

const json = (res, status, obj) => {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify(obj));
};
const auth = (req) => !TOKEN || req.headers.authorization === `Bearer ${TOKEN}`;
const body = (req) => new Promise((resolve, reject) => {
  let s = '';
  req.on('data', (c) => { s += c; if (s.length > 200000) reject(new Error('BODY_TOO_LARGE')); });
  req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch { reject(new Error('INVALID_JSON')); } });
});
const clean = (x) => typeof x === 'string' && x.length > 0 && x.length < 128;

http.createServer(async (req, res) => {
  try {
    if (!auth(req)) return json(res, 401, { error: 'UNAUTHORIZED' });
    const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const account = u.searchParams.get('account');

    if (req.method === 'GET' && u.pathname === '/health') {
      return json(res, 200, { ok: true, accounts: queues.size });
    }

    if (req.method === 'POST' && u.pathname === '/command') {
      const x = await body(req);
      if (!clean(x.clientCommandId) || !clean(x.accountId) || !clean(x.command) || x.accountId.length > 64) {
        return json(res, 400, { error: 'INVALID_COMMAND' });
      }
      if (account && x.accountId !== account) return json(res, 403, { error: 'ACCOUNT_BINDING' });
      const q = queues.get(x.accountId) || [];
      if (q.some((v) => v.clientCommandId === x.clientCommandId) || results.has(x.clientCommandId)) {
        return json(res, 200, { accepted: true, duplicate: true, clientCommandId: x.clientCommandId });
      }
      q.push({ ...x, issuedAt: Date.now() });
      queues.set(x.accountId, q);
      return json(res, 202, { accepted: true, clientCommandId: x.clientCommandId });
    }

    if (req.method === 'GET' && u.pathname === '/poll') {
      if (!clean(account)) return json(res, 400, { error: 'MISSING_ACCOUNT' });
      const q = queues.get(account) || [];
      let next = null;
      while (q.length) {
        const candidate = q.shift();
        if (Date.now() - candidate.issuedAt > COMMAND_TTL_MS) {
          results.set(candidate.clientCommandId, { ok: false, reason: 'EXPIRED', accountId: account, receivedAt: Date.now() });
          continue; // drop stale commands instead of ever handing them to the EA
        }
        next = candidate;
        break;
      }
      queues.set(account, q);
      return json(res, 200, next);
    }

    if (req.method === 'POST' && u.pathname === '/result') {
      const x = await body(req);
      if (!clean(x.clientCommandId) || !clean(x.accountId)) return json(res, 400, { error: 'INVALID_RESULT' });
      results.set(x.clientCommandId, { ...x, receivedAt: Date.now() });
      return json(res, 202, { accepted: true });
    }

    if (req.method === 'GET' && u.pathname === '/result') {
      const id = u.searchParams.get('command');
      return json(res, 200, id ? (results.get(id) || null) : null);
    }

    if (req.method === 'POST' && u.pathname === '/status') {
      const x = await body(req);
      if (!clean(x.accountId)) return json(res, 400, { error: 'MISSING_ACCOUNT' });
      statuses.set(x.accountId, { ...x, receivedAt: Date.now() });
      return json(res, 202, { accepted: true });
    }

    if (req.method === 'GET' && u.pathname === '/status') {
      return json(res, 200, clean(account) ? (statuses.get(account) || null) : null);
    }

    return json(res, 404, { error: 'NOT_FOUND' });
  } catch (e) {
    return json(res, 400, { error: e.message || 'BAD_REQUEST' });
  }
}).listen(PORT, () => console.log(`TASko relay listening on ${PORT} (command TTL ${COMMAND_TTL_MS}ms)`));
